﻿namespace StudyHub
{
    partial class AddProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ddl = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbl_upload = new System.Windows.Forms.Label();
            this.pnl_upload = new System.Windows.Forms.Panel();
            this.pb_upload = new System.Windows.Forms.PictureBox();
            this.lbl_filename = new System.Windows.Forms.Label();
            this.lbl_notes = new System.Windows.Forms.Label();
            this.txtbox_notes = new System.Windows.Forms.TextBox();
            this.btn_addproject = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pnl_upload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_ddl
            // 
            this.lbl_ddl.AutoSize = true;
            this.lbl_ddl.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_ddl.Location = new System.Drawing.Point(12, 9);
            this.lbl_ddl.Name = "lbl_ddl";
            this.lbl_ddl.Size = new System.Drawing.Size(159, 22);
            this.lbl_ddl.TabIndex = 0;
            this.lbl_ddl.Text = "Select Project Deadline:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 34);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // lbl_upload
            // 
            this.lbl_upload.AutoSize = true;
            this.lbl_upload.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_upload.Location = new System.Drawing.Point(12, 83);
            this.lbl_upload.Name = "lbl_upload";
            this.lbl_upload.Size = new System.Drawing.Size(106, 22);
            this.lbl_upload.TabIndex = 2;
            this.lbl_upload.Text = "Upload Project:";
            // 
            // pnl_upload
            // 
            this.pnl_upload.AllowDrop = true;
            this.pnl_upload.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_upload.Controls.Add(this.pb_upload);
            this.pnl_upload.Location = new System.Drawing.Point(16, 108);
            this.pnl_upload.Name = "pnl_upload";
            this.pnl_upload.Size = new System.Drawing.Size(300, 100);
            this.pnl_upload.TabIndex = 3;
            this.pnl_upload.Click += new System.EventHandler(this.pnl_upload_Click);
            this.pnl_upload.DragDrop += new System.Windows.Forms.DragEventHandler(this.pnl_upload_DragDrop);
            this.pnl_upload.DragEnter += new System.Windows.Forms.DragEventHandler(this.pnl_upload_DragEnter);
            this.pnl_upload.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_upload_Paint);
            // 
            // pb_upload
            // 
            this.pb_upload.Image = global::StudyHub.Properties.Resources.upload;
            this.pb_upload.Location = new System.Drawing.Point(105, 20);
            this.pb_upload.Name = "pb_upload";
            this.pb_upload.Size = new System.Drawing.Size(90, 60);
            this.pb_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_upload.TabIndex = 4;
            this.pb_upload.TabStop = false;
            this.pb_upload.Click += new System.EventHandler(this.pb_upload_Click);
            // 
            // lbl_filename
            // 
            this.lbl_filename.AutoSize = true;
            this.lbl_filename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_filename.Location = new System.Drawing.Point(14, 211);
            this.lbl_filename.Name = "lbl_filename";
            this.lbl_filename.Size = new System.Drawing.Size(100, 17);
            this.lbl_filename.TabIndex = 4;
            this.lbl_filename.Text = "No file chosen";
            this.lbl_filename.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_notes
            // 
            this.lbl_notes.AutoSize = true;
            this.lbl_notes.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_notes.Location = new System.Drawing.Point(12, 253);
            this.lbl_notes.Name = "lbl_notes";
            this.lbl_notes.Size = new System.Drawing.Size(152, 22);
            this.lbl_notes.TabIndex = 5;
            this.lbl_notes.Text = "Comments and Notes:";
            // 
            // txtbox_notes
            // 
            this.txtbox_notes.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtbox_notes.Location = new System.Drawing.Point(17, 278);
            this.txtbox_notes.Multiline = true;
            this.txtbox_notes.Name = "txtbox_notes";
            this.txtbox_notes.Size = new System.Drawing.Size(300, 95);
            this.txtbox_notes.TabIndex = 6;
            this.txtbox_notes.Text = "Add any project details or specific notes here...";
            this.txtbox_notes.Enter += new System.EventHandler(this.txtbox_notes_Enter);
            this.txtbox_notes.Leave += new System.EventHandler(this.txtbox_notes_Leave);
            // 
            // btn_addproject
            // 
            this.btn_addproject.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_addproject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_addproject.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addproject.Location = new System.Drawing.Point(43, 393);
            this.btn_addproject.Name = "btn_addproject";
            this.btn_addproject.Size = new System.Drawing.Size(102, 33);
            this.btn_addproject.TabIndex = 7;
            this.btn_addproject.Text = "Add Project";
            this.btn_addproject.UseVisualStyleBackColor = false;
            this.btn_addproject.Click += new System.EventHandler(this.btn_addproject_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.Red;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Location = new System.Drawing.Point(189, 393);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(102, 33);
            this.btn_cancel.TabIndex = 8;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // AddProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 438);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_addproject);
            this.Controls.Add(this.txtbox_notes);
            this.Controls.Add(this.lbl_notes);
            this.Controls.Add(this.lbl_filename);
            this.Controls.Add(this.pnl_upload);
            this.Controls.Add(this.lbl_upload);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbl_ddl);
            this.Name = "AddProject";
            this.Text = "AddProject";
            this.pnl_upload.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ddl;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbl_upload;
        private System.Windows.Forms.Panel pnl_upload;
        private System.Windows.Forms.PictureBox pb_upload;
        private System.Windows.Forms.Label lbl_filename;
        private System.Windows.Forms.Label lbl_notes;
        private System.Windows.Forms.TextBox txtbox_notes;
        private System.Windows.Forms.Button btn_addproject;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}