﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class Home : Form
    {
        // Your custom colors
        // Para rana sa sidebar
        Color activeColor = Color.FromArgb(250, 249, 238);   // Cream
        Color inactiveColor = Color.FromArgb(163, 177, 138); // Sage Green

        public Home()
        {
            InitializeComponent();
            ShowPage("Dashboard");
        }



        private void ShowPage(string pageName)
        {
            // 1. Hide all panels
            pnlDashboard.Visible = false;
            pnlAccount.Visible = false;
            pnlInbox.Visible = false;
            pnlHistory.Visible = false;

            // 2. Reset sidebar buttons to sage green
            btnDashboard.BackColor = inactiveColor;
            btnAccount.BackColor = inactiveColor;
            btnInbox.BackColor = inactiveColor;
            btnHistory.BackColor = inactiveColor;

            // Reset text colors
            btnDashboard.ForeColor = Color.Black;
            btnAccount.ForeColor = Color.Black;
            btnInbox.ForeColor = Color.Black;
            btnHistory.ForeColor = Color.Black;

            // 3. Dashboard Logic
            if (pageName == "Dashboard")
            {
                pnlDashboard.Visible = true;
                pnlDashboard.BringToFront(); //

                btnDashboard.BackColor = activeColor;
                btnDashboard.ForeColor = Color.Gray;

                btnAccount.BackColor = inactiveColor;
                btnAccount.ForeColor = Color.Black;


                // Keep the others inactive
                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            // 3. Account Logic
            else if (pageName == "Account")
            {
                pnlAccount.Visible = true;
                pnlAccount.BringToFront();

                btnAccount.BackColor = activeColor;
                btnAccount.ForeColor = Color.Gray;

                btnDashboard.BackColor = inactiveColor;
                btnDashboard.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            // 4. Inbox Logic
            else if (pageName == "Inbox")
            {
                pnlInbox.Visible = true;
                pnlInbox.BringToFront();
                btnInbox.BackColor = activeColor;
                btnInbox.ForeColor = Color.Gray;
            }
             // 5. History Logic
            else if (pageName == "History")
            {
                pnlHistory.Visible = true;
                pnlHistory.BringToFront();
                btnHistory.BackColor = activeColor;
                btnHistory.ForeColor = Color.Gray;
            }
        }

        // --- SIDEBAR CLICKS ---
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ShowPage("Dashboard");
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            ShowPage("Account");
        }

        private void btnInbox_Click(object sender, EventArgs e)
        {
            ShowPage("Inbox");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            ShowPage("History");
        }

        // --- SEARCH LOGIC (Keeps the Designer happy!) ---
        private void pbSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.ToLower();
            // This filters the cards in your flpProjects
            foreach (Control card in flpProjects.Controls)
            {
                card.Visible = card.Name.ToLower().Contains(query);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            // Placeholder for search box logic
        }

        private void x(object sender, PaintEventArgs e)
        {
            // wala rapud ni ahak. LIKAY OG DOUBLE PRESS dol aron dili ma in ani kay diko kabaw unsaon pagremove
        }

        // --- EMERGENCY PLACEHOLDERS (DO NOT DELETE) ---
        private void Home_Load(object sender, EventArgs e) { }
        private void button1_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel_home_Paint(object sender, PaintEventArgs e) { }
        private void pnlAccount_Paint_1(object sender, PaintEventArgs e) { }
        private void btnAccount_Click_1(object sender, EventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }

        private void lineShape4_Click(object sender, EventArgs e)
        {
            //wala rani ahak
        }

        //dark themes
        bool isDarkMode = false; //toggle
        private void btn_darkmode_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;

            if (isDarkMode)
            {
                // dark mode color
                this.BackColor = Color.FromArgb(30, 30, 30);
                pnlDashboard.BackColor = Color.FromArgb(45, 45, 45); 
                lblDashboard.ForeColor = Color.White;
                lblEmptyMessage.ForeColor = Color.White;
                pnlAccount.BackColor = Color.FromArgb(45, 45, 45);
                pnlInbox.BackColor = Color.FromArgb(45, 45, 45);
                pnlHistory.BackColor = Color.FromArgb(45, 45, 45);
                lblHistory.ForeColor = Color.White;
                txtSearch.BackColor = Color.FromArgb(60, 60, 60);
                txtSearch.ForeColor = Color.White;
                lblMessage.ForeColor = Color.White;
                lblPhone.ForeColor = Color.White;
                lblBday.ForeColor = Color.White;
                lblEmail.ForeColor = Color.White;
                lblName.ForeColor = Color.White;
                lblUser.ForeColor = Color.White;

                // main bg area of the table
                dgv_transhistory.BackgroundColor = Color.FromArgb(30, 30, 30);
                dgv_transhistory.GridColor = Color.FromArgb(60, 60, 60);
                // rows and cells
                dgv_transhistory.DefaultCellStyle.BackColor = Color.FromArgb(45, 45, 45);
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.White;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.Crimson; // Optional: change highlight color
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.White;
                // column headers Username, Project Title, etc.
                dgv_transhistory.EnableHeadersVisualStyles = false; // Must be false to allow custom colors
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                // main bg area of the table
                dgv_userhistory.BackgroundColor = Color.FromArgb(30, 30, 30);
                dgv_userhistory.GridColor = Color.FromArgb(60, 60, 60);
                // rows and cells
                dgv_userhistory.DefaultCellStyle.BackColor = Color.FromArgb(45, 45, 45);
                dgv_userhistory.DefaultCellStyle.ForeColor = Color.White;
                dgv_userhistory.DefaultCellStyle.SelectionBackColor = Color.Crimson; 
                dgv_userhistory.DefaultCellStyle.SelectionForeColor = Color.White;
                // column headers Username, Project Title, etc.
                dgv_userhistory.EnableHeadersVisualStyles = false; 
                dgv_userhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
                dgv_userhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                // change btn icon to day
                btn_darkmode.BackgroundImage = Properties.Resources.day_mode;
            }
            else
            {
                // default colors
                this.BackColor = Color.FromArgb(250, 249, 230);
                pnlDashboard.BackColor = Color.White;
                lblDashboard.ForeColor = Color.Black;
                lblEmptyMessage.ForeColor = Color.Black;
                pnlAccount.BackColor = Color.White;
                pnlInbox.BackColor = Color.White;
                pnlHistory.BackColor = Color.White;
                lblHistory.BackColor = Color.White;
                txtSearch.BackColor = Color.White;
                txtSearch.ForeColor = Color.Black;
                lblMessage.ForeColor = Color.Black;
                lblPhone.ForeColor = Color.Black;
                lblBday.ForeColor = Color.Black;
                lblEmail.ForeColor = Color.Black;
                lblName.ForeColor = Color.Black;
                lblUser.ForeColor = Color.Black;

                // Reset to Light Mode
                dgv_transhistory.BackgroundColor = Color.DarkGray;
                dgv_transhistory.GridColor = Color.LightGray;
                dgv_transhistory.DefaultCellStyle.BackColor = Color.White;
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.Black;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = SystemColors.Highlight;
                dgv_transhistory.EnableHeadersVisualStyles = true;

                dgv_userhistory.BackgroundColor = Color.DarkGray;
                dgv_userhistory.GridColor = Color.LightGray;
                dgv_userhistory.DefaultCellStyle.BackColor = Color.White;
                dgv_userhistory.DefaultCellStyle.ForeColor = Color.Black;
                dgv_userhistory.DefaultCellStyle.SelectionBackColor = SystemColors.Highlight;
                dgv_userhistory.EnableHeadersVisualStyles = true;
         
                btn_darkmode.BackgroundImage = Properties.Resources.night_mode;
            }
        }

        private void btnAddProject_Click(object sender, EventArgs e)
        {
            // 1. Create an "instance" of your new Add Project window
            using (AddProject window = new AddProject(isDarkMode))
            {
                // 2. Open it as a Modal Dialog.
                // This means the user MUST finish with this window 
                // before they can click anything else on the Dashboard.
                window.ShowDialog();
            }
        }
    }
}