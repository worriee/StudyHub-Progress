﻿namespace StudyHub
{
    partial class AddProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ddl = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbl_upload = new System.Windows.Forms.Label();
            this.pnl_upload = new System.Windows.Forms.Panel();
            this.pb_upload = new System.Windows.Forms.PictureBox();
            this.lbl_filename = new System.Windows.Forms.Label();
            this.lbl_notes = new System.Windows.Forms.Label();
            this.txtbox_notes = new System.Windows.Forms.TextBox();
            this.btn_addproject = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pnl_upload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_ddl
            // 
            this.lbl_ddl.AutoSize = true;
            this.lbl_ddl.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_ddl.Location = new System.Drawing.Point(14, 11);
            this.lbl_ddl.Name = "lbl_ddl";
            this.lbl_ddl.Size = new System.Drawing.Size(183, 24);
            this.lbl_ddl.TabIndex = 0;
            this.lbl_ddl.Text = "Select Project Deadline:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(14, 42);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(224, 26);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // lbl_upload
            // 
            this.lbl_upload.AutoSize = true;
            this.lbl_upload.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_upload.Location = new System.Drawing.Point(14, 104);
            this.lbl_upload.Name = "lbl_upload";
            this.lbl_upload.Size = new System.Drawing.Size(121, 24);
            this.lbl_upload.TabIndex = 2;
            this.lbl_upload.Text = "Upload Project:";
            // 
            // pnl_upload
            // 
            this.pnl_upload.AllowDrop = true;
            this.pnl_upload.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_upload.Controls.Add(this.pb_upload);
            this.pnl_upload.Location = new System.Drawing.Point(18, 135);
            this.pnl_upload.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnl_upload.Name = "pnl_upload";
            this.pnl_upload.Size = new System.Drawing.Size(338, 125);
            this.pnl_upload.TabIndex = 3;
            this.pnl_upload.Click += new System.EventHandler(this.pnl_upload_Click);
            this.pnl_upload.DragDrop += new System.Windows.Forms.DragEventHandler(this.pnl_upload_DragDrop);
            this.pnl_upload.DragEnter += new System.Windows.Forms.DragEventHandler(this.pnl_upload_DragEnter);
            this.pnl_upload.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_upload_Paint);
            // 
            // pb_upload
            // 
            this.pb_upload.Image = global::StudyHub.Properties.Resources.upload;
            this.pb_upload.Location = new System.Drawing.Point(118, 25);
            this.pb_upload.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pb_upload.Name = "pb_upload";
            this.pb_upload.Size = new System.Drawing.Size(101, 75);
            this.pb_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_upload.TabIndex = 4;
            this.pb_upload.TabStop = false;
            this.pb_upload.Click += new System.EventHandler(this.pb_upload_Click);
            // 
            // lbl_filename
            // 
            this.lbl_filename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_filename.Location = new System.Drawing.Point(15, 264);
            this.lbl_filename.Name = "lbl_filename";
            this.lbl_filename.Size = new System.Drawing.Size(350, 96);
            this.lbl_filename.TabIndex = 4;
            this.lbl_filename.Text = "No file chosen";
            this.lbl_filename.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_notes
            // 
            this.lbl_notes.AutoSize = true;
            this.lbl_notes.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_notes.Location = new System.Drawing.Point(14, 360);
            this.lbl_notes.Name = "lbl_notes";
            this.lbl_notes.Size = new System.Drawing.Size(177, 24);
            this.lbl_notes.TabIndex = 5;
            this.lbl_notes.Text = "Comments and Notes:";
            // 
            // txtbox_notes
            // 
            this.txtbox_notes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.txtbox_notes.Location = new System.Drawing.Point(19, 388);
            this.txtbox_notes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtbox_notes.Multiline = true;
            this.txtbox_notes.Name = "txtbox_notes";
            this.txtbox_notes.Size = new System.Drawing.Size(337, 118);
            this.txtbox_notes.TabIndex = 6;
            this.txtbox_notes.Text = "Add any project details or specific notes here...";
            this.txtbox_notes.Enter += new System.EventHandler(this.txtbox_notes_Enter);
            this.txtbox_notes.Leave += new System.EventHandler(this.txtbox_notes_Leave);
            // 
            // btn_addproject
            // 
            this.btn_addproject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.btn_addproject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_addproject.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addproject.Location = new System.Drawing.Point(48, 527);
            this.btn_addproject.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_addproject.Name = "btn_addproject";
            this.btn_addproject.Size = new System.Drawing.Size(115, 41);
            this.btn_addproject.TabIndex = 7;
            this.btn_addproject.Text = "Add Project";
            this.btn_addproject.UseVisualStyleBackColor = false;
            this.btn_addproject.Click += new System.EventHandler(this.btn_addproject_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Location = new System.Drawing.Point(196, 527);
            this.btn_cancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(115, 41);
            this.btn_cancel.TabIndex = 8;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // AddProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(249)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(398, 594);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_addproject);
            this.Controls.Add(this.txtbox_notes);
            this.Controls.Add(this.lbl_notes);
            this.Controls.Add(this.lbl_filename);
            this.Controls.Add(this.pnl_upload);
            this.Controls.Add(this.lbl_upload);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbl_ddl);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "AddProject";
            this.Text = "AddProject";
            this.pnl_upload.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ddl;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbl_upload;
        private System.Windows.Forms.Panel pnl_upload;
        private System.Windows.Forms.PictureBox pb_upload;
        private System.Windows.Forms.Label lbl_filename;
        private System.Windows.Forms.Label lbl_notes;
        private System.Windows.Forms.TextBox txtbox_notes;
        private System.Windows.Forms.Button btn_addproject;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}