﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyHub
{
    public static class UserSession
    {
        // This will hold the name of the person who logged in
        public static string FullName = "Guest User";
    }
}
