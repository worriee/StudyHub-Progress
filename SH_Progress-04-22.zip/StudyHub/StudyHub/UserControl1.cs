﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class DashboardCard : UserControl
    {
        public DashboardCard()
        {
            InitializeComponent();
        }

        public void SetProjectDetails(string name, string deadline, string title, string note)
        {
            lblUser.Text = "Name: " + name;
            lbldeadline.Text = "Deadline: " + deadline;
            lblProjectTitle.Text = title;
            lblNote.Text = "Note: " + note;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbldeadline_Click(object sender, EventArgs e)
        {

        }
    }
}
