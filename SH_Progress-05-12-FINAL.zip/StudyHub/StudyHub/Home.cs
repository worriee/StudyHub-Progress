﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data; // Namespace required for virtual DataTable manipulation

namespace StudyHub
{
    public partial class Home : Form
    {
        // Sidebar active and inactive custom background colors
        Color activeColor = Color.FromArgb(250, 249, 238);   // Cream
        Color inactiveColor = Color.FromArgb(163, 177, 138); // Sage Green

        // Dynamic Chat UI Controls
        private Panel pnlChatRoom = null;
        private FlowLayoutPanel flpChatMessages = null;
        private TextBox txtChatInput = null;
        private string activeChatRequester = "";
        private string activeChatProject = "";

        public Home()
        {
            InitializeComponent();
            ShowPage("Dashboard");
        }

        // Toggles active tab UI styles and manages multi-panel layout transitions
        private void ShowPage(string pageName)
        {
            pnlDashboard.Visible = false;
            pnlAccount.Visible = false;
            pnlInbox.Visible = false;
            pnlHistory.Visible = false;
            if (pnlChatRoom != null) pnlChatRoom.Visible = false; // Hide chat on page change

            btnDashboard.BackColor = inactiveColor;
            btnAccount.BackColor = inactiveColor;
            btnInbox.BackColor = inactiveColor;
            btnHistory.BackColor = inactiveColor;

            btnDashboard.ForeColor = Color.Black;
            btnAccount.ForeColor = Color.Black;
            btnInbox.ForeColor = Color.Black;
            btnHistory.ForeColor = Color.Black;

            if (pageName == "Dashboard")
            {
                pnlDashboard.Visible = true;
                pnlDashboard.BringToFront();

                btnDashboard.BackColor = activeColor;
                btnDashboard.ForeColor = Color.Gray;

                btnAccount.BackColor = inactiveColor;
                btnAccount.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            else if (pageName == "Account")
            {
                pnlAccount.Visible = true;
                pnlAccount.BringToFront();

                btnAccount.BackColor = activeColor;
                btnAccount.ForeColor = Color.Gray;

                btnDashboard.BackColor = inactiveColor;
                btnDashboard.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            else if (pageName == "Inbox")
            {
                pnlInbox.Visible = true;
                pnlInbox.BringToFront();
                btnInbox.BackColor = activeColor;
                btnInbox.ForeColor = Color.Gray;

                // Load fresh swap requests when user enters the inbox tab
                LoadInboxMessages();
            }
            else if (pageName == "History")
            {
                pnlHistory.Visible = true;
                pnlHistory.BringToFront();
                btnHistory.BackColor = activeColor;
                btnHistory.ForeColor = Color.Gray;
            }
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ShowPage("Dashboard");
        }

        // Updates user profile labels dynamically using global UserSession cache properties
        private void btnAccount_Click(object sender, EventArgs e)
        {
            ShowPage("Account");

            pnlAccount.Visible = true;
            pnlDashboard.Visible = false;

            // FIX: Combine FullName and Username using string.Format for VS 2012 compatibility
            lblName.Text = string.Format("Name: {0} | Username: {1}", UserSession.FullName, UserSession.Username);

            lblBday.Text = "Birthday: " + UserSession.Birthday;
            lblEmail.Text = "Email: " + UserSession.Email;
            lblPhone.Text = "Phone No. " + UserSession.Phone;

            if (UserSession.UserProfilePic != null)
            {
                pbProfile.Image = UserSession.UserProfilePic;
                pbProfile.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void btnInbox_Click(object sender, EventArgs e)
        {
            ShowPage("Inbox");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            ShowPage("History");
            LoadTransactionHistory();
        }

        // Triggers search filter checking against names of cards inside flpProjects panel
        private void pbSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.ToLower();
            foreach (Control card in flpProjects.Controls)
            {
                card.Visible = card.Name.ToLower().Contains(query);
            }

            FilterDashboard();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FilterDashboard();
        }

        private void x(object sender, PaintEventArgs e)
        {

        }

        // Loads both projects and transaction lists immediately on startup
        private void Home_Load(object sender, EventArgs e)
        {
            LoadProjectsFromDatabase();
            LoadTransactionHistory();
            cbLevels.SelectedIndex = 0; // Sets default selection of the Year Level dropdown to "All levels" on startup
        }

        private void button1_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) 
        {
            FilterDashboard();
        }
        private void panel_home_Paint(object sender, PaintEventArgs e) { }
        private void pnlAccount_Paint_1(object sender, PaintEventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }

        private void lineShape4_Click(object sender, EventArgs e)
        {

        }

        // Color structure theme mapping used for UI switching triggers
        bool isDarkMode = false;
        private void btn_darkmode_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;
            foreach (Control c in flpProjects.Controls)
            {
                DashboardCard card = c as DashboardCard;
                if (card != null)
                {
                    card.ApplyDarkMode(isDarkMode);
                }
            }

            // Apply dark theme properties to runtime chat room elements
            ApplyChatTheme();

            if (isDarkMode)
            {
                this.BackColor = Color.FromArgb(102, 102, 102);
                pnlDashboard.BackColor = Color.FromArgb(102, 102, 102);
                lblDashboard.ForeColor = Color.White;
                lblEmptyMessage.ForeColor = Color.White;
                pnlAccount.BackColor = Color.FromArgb(102, 102, 102);
                pnlInbox.BackColor = Color.FromArgb(102, 102, 102);
                pnlHistory.BackColor = Color.FromArgb(102, 102, 102);
                lblHistory.BackColor = Color.Transparent;
                lblHistory.ForeColor = Color.White;
                txtSearch.BackColor = Color.FromArgb(102, 102, 102);
                txtSearch.ForeColor = Color.White;
                lblMessage.ForeColor = Color.White;
                lblPhone.ForeColor = Color.White;
                lblBday.ForeColor = Color.White;
                lblEmail.ForeColor = Color.White;
                lblName.ForeColor = Color.White;
                lblUser.ForeColor = Color.White;

                cbLevels.FlatStyle = FlatStyle.Flat;
                cbLevels.BackColor = Color.FromArgb(102, 102, 102);
                cbLevels.ForeColor = Color.White;

                dgv_transhistory.BackgroundColor = Color.FromArgb(45, 45, 45);
                dgv_transhistory.GridColor = Color.FromArgb(60, 60, 60);

                dgv_transhistory.DefaultCellStyle.BackColor = Color.FromArgb(55, 55, 55);
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.White;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(80, 80, 80);
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.White;

                dgv_transhistory.EnableHeadersVisualStyles = false;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                btn_darkmode.BackgroundImage = Properties.Resources.light;
            }
            else
            {
                this.BackColor = Color.FromArgb(250, 249, 230);
                pnlDashboard.BackColor = Color.White;
                lblDashboard.ForeColor = Color.Black;
                lblEmptyMessage.ForeColor = Color.Black;
                pnlAccount.BackColor = Color.White;
                pnlInbox.BackColor = Color.White;
                pnlHistory.BackColor = Color.White;
                lblHistory.BackColor = Color.Transparent;
                lblHistory.ForeColor = Color.Black;
                txtSearch.BackColor = Color.White;
                txtSearch.ForeColor = Color.Black;
                lblMessage.ForeColor = Color.Black;
                lblPhone.ForeColor = Color.Black;
                lblBday.ForeColor = Color.Black;
                lblEmail.ForeColor = Color.Black;
                lblName.ForeColor = Color.Black;
                lblUser.ForeColor = Color.Black;
                cbLevels.FlatStyle = FlatStyle.Flat;
                cbLevels.BackColor = Color.White;
                cbLevels.ForeColor = Color.Black;

                dgv_transhistory.BackgroundColor = Color.FromArgb(240, 240, 240);
                dgv_transhistory.GridColor = Color.LightGray;

                dgv_transhistory.DefaultCellStyle.BackColor = Color.White;
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.Black;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(163, 177, 138);
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.Black;

                dgv_transhistory.EnableHeadersVisualStyles = false;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(163, 177, 138);
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;

                btn_darkmode.BackgroundImage = Properties.Resources.night_mode;
            }
        }

        // Activates new project dialog configuration and handles layout refreshes on return
        private void btnAddProject_Click(object sender, EventArgs e)
        {
            using (AddProject window = new AddProject(isDarkMode))
            {
                if (window.ShowDialog() == DialogResult.OK)
                {
                    // Clears the workspace and re-fetches updated project data directly from SQL
                    LoadProjectsFromDatabase();
                }
            }
        }

        private void dgv_transhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_userhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Closes dashboard processes, clears cached authentication variables, and opens login prompt
        private void btn_logout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Logout Confirmation",
                                              MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Stop the timer so it doesn't crash the app in the background
                timerRefresh.Stop();

                UserSession.Clear();
                Login loginWindow = new Login();
                loginWindow.Show();

                this.Close(); // Use Close() instead of Hide() to kill the Home process
            }
        }

        // Selects and populates all existing records inside UserControl table onto FlowLayoutPanel
        private void LoadProjectsFromDatabase()
        {
            flpProjects.Controls.Clear();
            string query = "SELECT FullName, Deadline, ProjectTitle, Notes, FileAttached, YearLevel FROM UserControl ORDER BY ProjectId DESC";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            bool hasProjects = false;
                            while (reader.Read())
                            {
                                hasProjects = true;
                                DashboardCard card = new DashboardCard(isDarkMode);

                                string uploaderName = reader["FullName"].ToString();
                                string deadline = reader["Deadline"].ToString();
                                string title = reader["ProjectTitle"].ToString();
                                string notes = reader["Notes"] != DBNull.Value ? reader["Notes"].ToString() : "";
                                string file = reader["FileAttached"] != DBNull.Value ? reader["FileAttached"].ToString() : "";
                                string yearLevel = reader["YearLevel"] != DBNull.Value ? reader["YearLevel"].ToString() : "N/A";

                                // Passes the year level down to the visual card properties
                                card.SetProjectDetails(uploaderName, deadline, title, notes, file, yearLevel);
                                flpProjects.Controls.Add(card);
                            }

                            lblEmptyMessage.Visible = !hasProjects;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading projects: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Queries the transHistory table with a filter to strictly fetch only the active user's transactions
        public void LoadTransactionHistory()
        {
            // Safety Check: If no one is logged in, don't run the query! related ni sa timer refresh
            if (string.IsNullOrEmpty(UserSession.Username))
            {
                return;
            }

            // Filter strictly by the current logged-in Username
            string query = "SELECT Username, ProjectTitle, Deadline, Status FROM transHistory WHERE Username = @Username ORDER BY Id DESC";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Ensure the session username is passed correctly
                        cmd.Parameters.AddWithValue("@Username", UserSession.Username);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dgv_transhistory.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Triggers when selecting a level from the cbLevels ComboBox to filter DashboardCards
        private void cbLevels_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedLevel = cbLevels.SelectedItem != null ? cbLevels.SelectedItem.ToString() : "All levels";

            foreach (Control c in flpProjects.Controls)
            {
                DashboardCard card = c as DashboardCard;
                if (card != null)
                {
                    // Show everything if "All levels" is chosen, otherwise check if card matches selected year level
                    if (selectedLevel.Equals("All levels", StringComparison.OrdinalIgnoreCase))
                    {
                        card.Visible = true;
                    }
                    else
                    {
                        card.Visible = card.YearLevel.Equals(selectedLevel, StringComparison.OrdinalIgnoreCase);
                    }
                }
            }
        }

        // Loads transaction requests sent to the active user's projects (Loads all states to display complete/cancelled cards)
        private void LoadInboxMessages()
        {
            if (string.IsNullOrEmpty(UserSession.Username)) return;

            flpMessages.Controls.Clear();

            // JOIN t1 (You) with t2 (The Partner) on the same ProjectTitle
            string query = @"
        SELECT 
            t2.Username AS PartnerUsername, 
            t1.ProjectTitle, 
            t1.Status,
            u.Notes, 
            u.FileAttached
        FROM transHistory t1
        INNER JOIN transHistory t2 ON t1.ProjectTitle = t2.ProjectTitle AND t1.Username != t2.Username
        INNER JOIN UserControl u ON t1.ProjectTitle = u.ProjectTitle
        WHERE t1.Username = @CurrentUsername";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@CurrentUsername", UserSession.Username);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string partnerUsername = reader["PartnerUsername"].ToString();
                                string title = reader["ProjectTitle"].ToString();
                                string status = reader["Status"].ToString();
                                string notes = reader["Notes"] != DBNull.Value ? reader["Notes"].ToString() : "";
                                string file = reader["FileAttached"] != DBNull.Value ? reader["FileAttached"].ToString() : "";

                                // Use your helper method to get the partner's real name from loginDetails.mdf
                                string partnerFullName = GetFullNameFromLoginDB(partnerUsername);

                                MessageCard mCard = new MessageCard();
                                // Send partnerFullName as the first parameter
                                mCard.SetMessageDetails(partnerFullName, partnerUsername, notes, file, title, status);
                                flpMessages.Controls.Add(mCard);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading inbox: " + ex.Message);
            }
        }

        // Helper method to reach into the other Database file safely
        private string GetFullNameFromLoginDB(string username)
        {
            string name = username; // Default to username if name not found
            string nameQuery = "SELECT FullName FROM loginDetails WHERE Username = @user";

            try
            {
                using (SqlConnection conn = Database.GetConnection()) // Use the main connection (loginDetails.mdf)
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(nameQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@user", username);
                        object result = cmd.ExecuteScalar();
                        if (result != null) name = result.ToString();
                    }
                }
            }
            catch { /* Handle potential connection issues silently */ }

            return name;
        }

        // Opens the runtime Chat Room collaboration workspace
        public void OpenChatRoom(string requesterUsername, string projectTitle, string projectNotes, string attachedFile)
        {
            activeChatRequester = requesterUsername;
            activeChatProject = projectTitle;

            // Dynamically generate the Chat panel layout if it doesn't exist yet
            if (pnlChatRoom == null)
            {
                InitializeChatRoomUI();
            }

            // Populate the summary panel controls (left side) with current project information
            Label lblChatTitle = (Label)pnlChatRoom.Controls.Find("lblChatTitle", true)[0];
            Label lblChatNotes = (Label)pnlChatRoom.Controls.Find("lblChatNotes", true)[0];
            Label lblChatFile = (Label)pnlChatRoom.Controls.Find("lblChatFile", true)[0];

            lblChatTitle.Text = "Project Title: " + projectTitle;
            lblChatNotes.Text = "Project Notes: " + projectNotes;
            lblChatFile.Text = "Attached File: " + attachedFile;

            // Parented inside pnlMainContent boundaries cleanly to avoid blocking sidebar layout
            pnlChatRoom.Size = pnlInbox.Size;
            pnlChatRoom.Location = pnlInbox.Location;
            pnlChatRoom.Visible = true;
            pnlChatRoom.BringToFront();

            // Load existing chat history from the SQL Server database
            LoadChatHistory();
        }

        // Dynamically builds the Split-Screen UI elements for the Chat Room workspace
        private void InitializeChatRoomUI()
        {
            // Main Chat Container
            pnlChatRoom = new Panel();
            pnlChatRoom.Name = "pnlChatRoom";

            // MOVES THE UI TO THE RIGHT: 
            // This padding ensures the chat room starts after your left sidebar navigation
            pnlChatRoom.Padding = new Padding(100, 0, 0, 0); //HERE IS THE LEFT SIDE = SUCCESS
            pnlChatRoom.Dock = DockStyle.Fill;
            pnlMainContent.Controls.Add(pnlChatRoom);

            // LEFT COLUMN: Project Overview
            Panel pnlLeftSummary = new Panel();
            pnlLeftSummary.Name = "pnlLeftSummary";
            pnlLeftSummary.Dock = DockStyle.Left;
            pnlLeftSummary.Width = 320;
            pnlLeftSummary.Padding = new Padding(20);
            pnlChatRoom.Controls.Add(pnlLeftSummary);

            // Container for Left Text to separate from bottom buttons
            Panel pnlLeftText = new Panel();
            pnlLeftText.Dock = DockStyle.Fill;
            pnlLeftSummary.Controls.Add(pnlLeftText);

            /*Label lblSummaryHeader = new Label();
            lblSummaryHeader.Text = "SWAP PROJECT OVERVIEW";
            lblSummaryHeader.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            lblSummaryHeader.Dock = DockStyle.Top;
            lblSummaryHeader.Height = 45;
            pnlLeftText.Controls.Add(lblSummaryHeader);*/

            Label lblChatTitle = new Label();
            lblChatTitle.Name = "lblChatTitle";
            lblChatTitle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblChatTitle.Dock = DockStyle.Top;
            lblChatTitle.Height = 160;
            pnlLeftText.Controls.Add(lblChatTitle);

            Label lblChatNotes = new Label();
            lblChatNotes.Name = "lblChatNotes";
            lblChatNotes.Font = new Font("Segoe UI", 9);
            lblChatNotes.Dock = DockStyle.Top;
            lblChatNotes.Height = 140;
            pnlLeftText.Controls.Add(lblChatNotes);

            Label lblChatFile = new Label();
            lblChatFile.Name = "lblChatFile";
            lblChatFile.Font = new Font("Segoe UI", 9, FontStyle.Italic);
            lblChatFile.Dock = DockStyle.Top;
            lblChatFile.Height = 40;
            pnlLeftText.Controls.Add(lblChatFile);

            // BOTTOM BUTTONS: Stacked in the left column
            Panel pnlLeftButtons = new Panel();
            pnlLeftButtons.Dock = DockStyle.Bottom;
            pnlLeftButtons.Height = 180;
            pnlLeftSummary.Controls.Add(pnlLeftButtons);

            Button btnMarkCancelled = new Button();
            btnMarkCancelled.Text = "Cancel Swap";
            btnMarkCancelled.Dock = DockStyle.Bottom;
            btnMarkCancelled.Height = 45;
            btnMarkCancelled.FlatStyle = FlatStyle.Flat;
            btnMarkCancelled.BackColor = Color.FromArgb(230, 100, 100); // Soft Red [cite: 25]
            btnMarkCancelled.ForeColor = Color.Black;
            btnMarkCancelled.Click += new EventHandler(btnMarkCancelled_Click);
            pnlLeftButtons.Controls.Add(btnMarkCancelled);

            Panel spacer1 = new Panel() { Dock = DockStyle.Bottom, Height = 10 };
            pnlLeftButtons.Controls.Add(spacer1);

            Button btnMarkCompleted = new Button();
            btnMarkCompleted.Text = "Complete Swap";
            btnMarkCompleted.Dock = DockStyle.Bottom;
            btnMarkCompleted.Height = 45;
            btnMarkCompleted.FlatStyle = FlatStyle.Flat;
            btnMarkCompleted.BackColor = Color.FromArgb(163, 177, 138); // Sage Green [cite: 24]
            btnMarkCompleted.ForeColor = Color.Black;
            btnMarkCompleted.Click += new EventHandler(btnMarkCompleted_Click);
            pnlLeftButtons.Controls.Add(btnMarkCompleted);

            Panel spacer2 = new Panel() { Dock = DockStyle.Bottom, Height = 10 };
            pnlLeftButtons.Controls.Add(spacer2);

            Button btnBackToInbox = new Button();
            btnBackToInbox.Text = "Back to Inbox";
            btnBackToInbox.Dock = DockStyle.Bottom;
            btnBackToInbox.Height = 45;
            btnBackToInbox.FlatStyle = FlatStyle.Flat;
            btnBackToInbox.Click += new EventHandler(btnBackToInbox_Click);
            pnlLeftButtons.Controls.Add(btnBackToInbox);

            // RIGHT COLUMN: Messenger Panel
            Panel pnlRightChat = new Panel();
            pnlRightChat.Name = "pnlRightChat";
            pnlRightChat.Padding = new Padding(350, 0, 0, 0);
            pnlRightChat.Dock = DockStyle.Fill;
            pnlChatRoom.Controls.Add(pnlRightChat);

            // Message Input Bar
            Panel pnlMessageInputBar = new Panel();
            pnlMessageInputBar.Name = "pnlMessageInputBar";
            pnlMessageInputBar.Dock = DockStyle.Bottom;
            pnlMessageInputBar.Height = 70; 

            pnlMessageInputBar.Padding = new Padding(20, 25, 20, 15);
            pnlRightChat.Controls.Add(pnlMessageInputBar);

            Button btnSendChat = new Button();
            btnSendChat.Text = "Send";
            btnSendChat.Dock = DockStyle.Right;

            //send chat ui
            btnSendChat.Width = 45;
            btnSendChat.FlatStyle = FlatStyle.Flat;
            btnSendChat.Click += new EventHandler(btnSendChat_Click);
            pnlMessageInputBar.Controls.Add(btnSendChat);

            // Spacer between TextBox and Button
            Panel spacerChat = new Panel() { Dock = DockStyle.Right, Width = 20 };
            pnlMessageInputBar.Controls.Add(spacerChat);

            txtChatInput = new TextBox();
            txtChatInput.Name = "txtChatInput";
            txtChatInput.Dock = DockStyle.Fill;
            txtChatInput.Font = new Font("Segoe UI", 11);
            pnlMessageInputBar.Controls.Add(txtChatInput);

            // Chat Message Log
            flpChatMessages = new FlowLayoutPanel();
            flpChatMessages.Name = "flpChatMessages";
            flpChatMessages.Dock = DockStyle.Fill;
            flpChatMessages.AutoScroll = true;
            flpChatMessages.FlowDirection = FlowDirection.TopDown;
            flpChatMessages.WrapContents = false;
            flpChatMessages.Padding = new Padding(15);
            pnlRightChat.Controls.Add(flpChatMessages);

            ApplyChatTheme();
        }

        // Closes Chat panel and refreshes main inbox messages
        private void btnBackToInbox_Click(object sender, EventArgs e)
        {
            if (pnlChatRoom != null)
            {
                pnlChatRoom.Visible = false;
            }
            LoadInboxMessages();
        }

        // Handles clicking the "Complete Swap" option
        private void btnMarkCompleted_Click(object sender, EventArgs e)
        {
            UpdateTransactionChoice("Completed");
        }

        // Handles clicking the "Cancel Swap" option
        private void btnMarkCancelled_Click(object sender, EventArgs e)
        {
            UpdateTransactionChoice("Cancelled");
        }

        // Records user vote to DB and changes transaction status if consensus is met
        //kato ning confirm swap ug cancel swap nga logic nila
        private void UpdateTransactionChoice(string choice)
        {
            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();

                    // 1. Determine role (Optional now, but kept for clean data)
                    string roleQuery = "SELECT Username FROM transHistory WHERE ProjectTitle = @ProjectTitle AND Username = @Username";
                    bool isRequester = false;
                    using (SqlCommand cmdRole = new SqlCommand(roleQuery, conn))
                    {
                        cmdRole.Parameters.AddWithValue("@ProjectTitle", activeChatProject);
                        cmdRole.Parameters.AddWithValue("@Username", UserSession.Username);
                        if (cmdRole.ExecuteScalar() != null) isRequester = true;
                    }

                    string targetColumn = isRequester ? "RequesterChoice" : "OwnerChoice";

                    // 2. Update the individual choice for both records
                    string updateQuery = string.Format(
                        "UPDATE transHistory SET {0} = @Choice WHERE ProjectTitle = @ProjectTitle",
                        targetColumn
                    );

                    using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Choice", choice);
                        cmd.Parameters.AddWithValue("@ProjectTitle", activeChatProject);
                        cmd.ExecuteNonQuery();
                    }

                    // 3. SIMPLIFIED SYNC: If EITHER user clicks choice, update the Status immediately
                    // Changing 'AND' to 'OR' removes the consensus requirement
                    string syncQuery = @"UPDATE transHistory SET Status = 
                                CASE 
                                    WHEN RequesterChoice = 'Completed' OR OwnerChoice = 'Completed' THEN 'Completed' 
                                    WHEN RequesterChoice = 'Cancelled' OR OwnerChoice = 'Cancelled' THEN 'Cancelled' 
                                    ELSE 'Pending' 
                                END 
                                WHERE ProjectTitle = @ProjectTitle";

                    using (SqlCommand cmdSync = new SqlCommand(syncQuery, conn))
                    {
                        cmdSync.Parameters.AddWithValue("@ProjectTitle", activeChatProject);
                        cmdSync.ExecuteNonQuery();
                    }

                    // 4. Send System Notification so the partner knows it's finished
                    string notifyMsg = string.Format("[SYSTEM]: {0} has officially {1} this swap.", UserSession.Username, choice);
                    string chatQuery = "INSERT INTO ChatHistory (ProjectTitle, SenderUsername, MessageText) VALUES (@ProjectTitle, @Sender, @MsgText)";
                    using (SqlCommand cmdNotify = new SqlCommand(chatQuery, conn))
                    {
                        cmdNotify.Parameters.AddWithValue("@ProjectTitle", activeChatProject);
                        cmdNotify.Parameters.AddWithValue("@Sender", "System");
                        cmdNotify.Parameters.AddWithValue("@MsgText", notifyMsg);
                        cmdNotify.ExecuteNonQuery();
                    }

                    // Refresh UI
                    LoadTransactionHistory();
                    LoadInboxMessages();
                    LoadChatHistory();

                    MessageBox.Show("Transaction has been officially " + choice + "!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Appends fresh user message into SQL database and updates conversation timeline
        private void btnSendChat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtChatInput.Text)) return;

            string query = "INSERT INTO ChatHistory (ProjectTitle, SenderUsername, MessageText) VALUES (@ProjectTitle, @Sender, @MsgText)";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ProjectTitle", activeChatProject);
                        cmd.Parameters.AddWithValue("@Sender", UserSession.Username);
                        cmd.Parameters.AddWithValue("@MsgText", txtChatInput.Text);

                        cmd.ExecuteNonQuery();
                    }
                }

                txtChatInput.Clear(); // Flush message text input field
                LoadChatHistory();   // Dynamic UI reload of discussion log entries
            }
            catch (Exception ex)
            {
                MessageBox.Show("Message Error: " + ex.Message, "Send Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Selects messaging history from database and populates UI discussion bubbles
        private void LoadChatHistory()
        {
            if (flpChatMessages == null) return;
            flpChatMessages.Controls.Clear();

            string query = "SELECT SenderUsername, MessageText, Timestamp FROM ChatHistory WHERE ProjectTitle = @ProjectTitle ORDER BY MessageId ASC";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ProjectTitle", activeChatProject);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string sender = reader["SenderUsername"].ToString();
                                string text = reader["MessageText"].ToString();
                                DateTime time = Convert.ToDateTime(reader["Timestamp"]);

                                Panel pnlBubble = new Panel();
                                pnlBubble.Width = flpChatMessages.Width - 30;
                                pnlBubble.Height = 45;
                                pnlBubble.Margin = new Padding(5);

                                Label lblBubbleText = new Label();
                                lblBubbleText.Text = "[" + time.ToString("hh:mm tt") + "] " + sender + ": " + text;
                                lblBubbleText.AutoSize = true;
                                lblBubbleText.Location = new Point(10, 10);
                                lblBubbleText.Font = new Font("Arial", 9);

                                // Alignment styling checks based on message ownership properties
                                if (sender.Equals(UserSession.Username, StringComparison.OrdinalIgnoreCase))
                                {
                                    pnlBubble.BackColor = Color.FromArgb(163, 177, 138); // Self: Sage Green bubble color
                                    lblBubbleText.ForeColor = Color.Black;
                                }
                                else
                                {
                                    pnlBubble.BackColor = Color.LightGray; // Other: classic light gray container styles
                                    lblBubbleText.ForeColor = Color.Black;
                                }

                                pnlBubble.Controls.Add(lblBubbleText);
                                flpChatMessages.Controls.Add(pnlBubble);
                            }
                        }
                    }
                }

                // Autoscroll direct container to show the latest entries
                flpChatMessages.ScrollControlIntoView(flpChatMessages.Controls.Count > 0 ? flpChatMessages.Controls[flpChatMessages.Controls.Count - 1] : null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading chat history: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // chatroom darkmode
        private void ApplyChatTheme()
        {
            if (pnlChatRoom == null) return;

            Panel pnlLeftSummary = (Panel)pnlChatRoom.Controls.Find("pnlLeftSummary", true)[0];
            Panel pnlRightChat = (Panel)pnlChatRoom.Controls.Find("pnlRightChat", true)[0];

            // FIXED: Cleanly locate 'pnlMessageInputBar' by name to bypass index exception bugs completely
            Panel pnlMessageInputBar = (Panel)pnlRightChat.Controls.Find("pnlMessageInputBar", true)[0];

            if (isDarkMode)
            {
                pnlChatRoom.BackColor = Color.FromArgb(102, 102, 102);
                pnlLeftSummary.BackColor = Color.FromArgb(84, 84, 84);
                pnlRightChat.BackColor = Color.FromArgb(102, 102, 102);
                flpChatMessages.BackColor = Color.FromArgb(45, 45, 45);
                pnlMessageInputBar.BackColor = Color.FromArgb(84, 84, 84); // Theme background fix

                foreach (Control c in pnlLeftSummary.Controls)
                {
                    if (c is Label) c.ForeColor = Color.White;
                }
            }
            else
            {
                pnlChatRoom.BackColor = Color.FromArgb(250, 249, 230);
                pnlLeftSummary.BackColor = Color.FromArgb(218, 210, 188);
                pnlRightChat.BackColor = Color.FromArgb(250, 249, 230);
                flpChatMessages.BackColor = Color.White;
                pnlMessageInputBar.BackColor = Color.FromArgb(218, 210, 188); // Theme background fix

                foreach (Control c in pnlLeftSummary.Controls)
                {
                    if (c is Label) c.ForeColor = Color.Black;
                }
            }
        }

        private void pnlHistory_Paint(object sender, PaintEventArgs e)
        {

        }

        //gamit ng timer para tig refresh nya updated pirme like realtime ang Transaction History, Messages ug Chat Room sa Dashboard
        //every 5secs mo refresh
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Automatically re-sync data from SQL every 5 seconds
            // This allows the "other user" to see status changes without clicking anything
            LoadTransactionHistory();

            // Only refresh the Inbox if it's currently visible to save resources
            if (pnlInbox.Visible)
            {
                LoadInboxMessages();
            }

            // If a chat room is open, refresh the messages too
            if (pnlChatRoom != null && pnlChatRoom.Visible)
            {
                LoadChatHistory();
            }
        }

        private void FilterDashboard()
        {
            // Handle the placeholder text "Search"
            string searchText = txtSearch.Text;
            if (searchText == "Search") searchText = "";
            searchText = searchText.ToLower().Trim();

            string selectedLevel = cbLevels.SelectedItem != null ? cbLevels.SelectedItem.ToString() : "All levels";

            foreach (Control control in flpProjects.Controls)
            {
                DashboardCard card = control as DashboardCard;
                if (card != null)
                {
                    // 1. Check Search (Null-safe)
                    bool matchesSearch = string.IsNullOrEmpty(searchText) ||
                                         (card.UploaderName != null && card.UploaderName.ToLower().Contains(searchText)) ||
                                         (card.ProjectTitle != null && card.ProjectTitle.ToLower().Contains(searchText));

                    // 2. Check Year Level (Null-safe)
                    bool matchesLevel = selectedLevel.Equals("All levels", StringComparison.OrdinalIgnoreCase) ||
                                        (card.YearLevel != null && card.YearLevel.Equals(selectedLevel, StringComparison.OrdinalIgnoreCase));

                    // 3. Apply Visibility
                    card.Visible = matchesSearch && matchesLevel;
                }
            }

            // Refresh "No projects found" label
            bool anyVisible = false;
            foreach (Control c in flpProjects.Controls)
            {
                if (c is DashboardCard && c.Visible) anyVisible = true;
            }
            lblEmptyMessage.Visible = !anyVisible;
        }
    }
}