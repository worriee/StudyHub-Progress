﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace StudyHub
{
    public partial class PersonalInfo : Form
    {
        // Holds the exact physical file location of the selected profile photo on your drive
        private string selectedPhotoPath = "";

        public PersonalInfo()
        {
            InitializeComponent();
        }

        // Action when clicking the profile picture box icon to browse files
        private void pb_usericon_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pb_userimage.Image = Image.FromFile(ofd.FileName);
                selectedPhotoPath = ofd.FileName; // Save the file path to write to our SQL table
                pb_userimage.Tag = "Uploaded";   // Flag used to notify progress timer calculation
            }
        }

        // Triggers validation check, saves to SQL, and moves to Home Dashboard
        private void btn_userInfo_Click(object sender, EventArgs e)
        {
            // Validation 1: Confirm picture is selected
            if (pb_userimage.Image == null || pb_userimage.Tag == null || pb_userimage.Tag.ToString() != "Uploaded")
            {
                MessageBox.Show("Please upload a profile photo first.", "Missing Photo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validation 2: Ensure full name is entered
            if (string.IsNullOrWhiteSpace(txt_fullname.Text))
            {
                MessageBox.Show("Please enter your Full Name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_fullname.Focus();
                return;
            }

            // Validation 3: Ensure phone starts with 09 and is exactly 11 digits long
            if (!Regex.IsMatch(txt_phone.Text, @"^09[0-9]{9}$"))
            {
                MessageBox.Show("Please enter a valid 11-digit phone number starting with 09.", "Invalid Phone", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_phone.Focus();
                return;
            }

            // Validation 4: Validate email address layout via regular expressions
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(txt_email.Text, emailPattern))
            {
                MessageBox.Show("Please enter a valid email address (e.g., user@gmail.com).", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_email.Focus();
                return;
            }

            // Validation 5: Calculate age and ensure user is at least 15 years old
            DateTime bday = dtp_userbd.Value;
            DateTime today = DateTime.Today;
            int age = today.Year - bday.Year;
            if (bday > today.AddYears(-age)) age--;

            if (bday >= today)
            {
                MessageBox.Show("Birthday cannot be today or in the future.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (age < 18)
            {
                MessageBox.Show("You must be at least 18 years old to use StudyHub.", "Age Restriction", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Run SQL UPDATE statement to save user details using active UserSession.UserId
            using (SqlConnection conn = Database.GetConnection())
            {
                conn.Open();
                string query = "UPDATE loginDetails SET FullName = @FullName, Email = @Email, Phone = @Phone, Birthday = @Birthday, PhotoPath = @PhotoPath WHERE UserId = @UserId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@FullName", txt_fullname.Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", txt_email.Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", txt_phone.Text.Trim());
                    cmd.Parameters.AddWithValue("@Birthday", dtp_userbd.Value.ToShortDateString());
                    cmd.Parameters.AddWithValue("@PhotoPath", selectedPhotoPath);
                    cmd.Parameters.AddWithValue("@UserId", UserSession.UserId);

                    cmd.ExecuteNonQuery();
                }
            }

            // Populate current in-memory UserSession variables with newly updated profile inputs
            UserSession.FullName = txt_fullname.Text;
            UserSession.Email = txt_email.Text;
            UserSession.Phone = txt_phone.Text;
            UserSession.Birthday = dtp_userbd.Value.ToShortDateString();
            UserSession.UserProfilePic = pb_userimage.Image;

            Home window = new Home();
            window.Show();
            this.Hide();
        }

        int progressWidth = 0;
        // Timer handler that expands or shrinks the custom progress bar line around our button
        private void progressTimer_Tick(object sender, EventArgs e)
        {
            int targetWidth = CalculateTargetProgress();

            if (progressWidth < targetWidth)
            {
                progressWidth += 2;
            }
            else if (progressWidth > targetWidth)
            {
                progressWidth -= 2;
            }

            btn_userInfo.Invalidate();
        }

        // Checks user input fields to dynamically calculate registration completion percentage (20% per field)
        private int CalculateTargetProgress()
        {
            int completedFields = 0;

            if (pb_userimage.Tag != null && pb_userimage.Tag.ToString() == "Uploaded") completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_fullname.Text)) completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_email.Text)) completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_phone.Text)) completedFields++;
            if (dtp_userbd.Value.Date != DateTime.Today) completedFields++;

            return completedFields * 20;
        }

        // Paints the custom borders progress outline line directly onto the Save Button surface
        private void btn_userInfo_Paint(object sender, PaintEventArgs e)
        {
            Pen p = new Pen(Color.Black, 1);
            int w = btn_userInfo.Width;
            int h = btn_userInfo.Height;

            float totalPerimeter = (w * 2) + (h * 2);
            float currentDist = (totalPerimeter * progressWidth) / 100f;

            float drawBottom = Math.Min(currentDist, w);
            if (drawBottom > 0)
                e.Graphics.DrawLine(p, 0, h - 2, drawBottom, h - 2);

            if (currentDist > w)
            {
                float drawRight = Math.Min(currentDist - w, h);
                e.Graphics.DrawLine(p, w - 2, h, w - 2, h - drawRight);
            }

            if (currentDist > (w + h))
            {
                float drawTop = Math.Min(currentDist - (w + h), w);
                e.Graphics.DrawLine(p, w, 2, w - drawTop, 2);
            }

            if (currentDist > (w * 2 + h))
            {
                float drawLeft = Math.Min(currentDist - (w * 2 + h), h);
                e.Graphics.DrawLine(p, 2, 0, 2, drawLeft);
            }
        }

        private void lbl_profile_Click(object sender, EventArgs e)
        {

        }

        private void PersonalInfo_Load(object sender, EventArgs e)
        {

        }
    }
}