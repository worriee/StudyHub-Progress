﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudyHub
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void pb_usericon_Click(object sender, EventArgs e)
        {

        }

        // Swaps the interface layout between "Login" and "Signup" states
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (btn_action.Text == "Signup")
            {
                btn_action.Text = "Login";
                lbl_welcome.Text = "Welcome Back!";
                lbl_welcome.Visible = true;
                lbl_action.Text = "Signup/Create New Account";
            }
            else
            {
                btn_action.Text = "Signup";
                lbl_welcome.Visible = false;
                lbl_action.Text = "Login with existing account.";
            }
        }

        // Executed when clicking the Signup / Login button
        private void btn_action_Click(object sender, EventArgs e)
        {
            // Stop if the username or password textboxes are left blank
            if (string.IsNullOrWhiteSpace(textBox_usn.Text) || string.IsNullOrWhiteSpace(textBox_pass.Text))
            {
                MessageBox.Show("Username and Password cannot be empty!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Enforce basic minimum password length boundary
            if (textBox_pass.Text.Length < 10)
            {
                MessageBox.Show("Password must be at least 10 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string username = textBox_usn.Text.Trim();
            string password = textBox_pass.Text.Trim();

            // SIGNUP FLOW: Creating a brand new account
            if (btn_action.Text == "Signup")
            {
                using (SqlConnection conn = Database.GetConnection())
                {
                    conn.Open();

                    // Search database to see if the chosen username is already taken
                    string checkQuery = "SELECT COUNT(*) FROM loginDetails WHERE Username = @Username";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Username", username);
                        int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                        // Stop the signup process if the username is already registered in the DB
                        if (count > 0)
                        {
                            MessageBox.Show("This account is already made! Please choose a different username or switch to Login.", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Insert credentials and return the auto-incremented UserId using SCOPE_IDENTITY()
                    string insertQuery = "INSERT INTO loginDetails (Username, Password) VALUES (@Username, @Password); SELECT SCOPE_IDENTITY();";
                    using (SqlCommand insertCmd = new SqlCommand(insertQuery, conn))
                    {
                        insertCmd.Parameters.AddWithValue("@Username", username);
                        insertCmd.Parameters.AddWithValue("@Password", password);

                        object result = insertCmd.ExecuteScalar();
                        if (result != null)
                        {
                            // Store the new UserId and Username in our active session
                            UserSession.UserId = Convert.ToInt32(result);
                            UserSession.Username = username;

                            MessageBox.Show("Account registered! Let's set up your profile details.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Send new signups directly to PersonalInfo to fill out their profile details
                            PersonalInfo personalInfoWindow = new PersonalInfo();
                            personalInfoWindow.Show();
                            this.Hide();
                        }
                    }
                }
            }
            // LOGIN FLOW: Accessing an already existing account
            else
            {
                using (SqlConnection conn = Database.GetConnection())
                {
                    conn.Open();

                    // Select all profile details for the matching credentials
                    string loginQuery = "SELECT UserId, Username, FullName, Email, Phone, Birthday, PhotoPath FROM loginDetails WHERE Username = @Username AND Password = @Password";
                    using (SqlCommand loginCmd = new SqlCommand(loginQuery, conn))
                    {
                        loginCmd.Parameters.AddWithValue("@Username", username);
                        loginCmd.Parameters.AddWithValue("@Password", password);

                        using (SqlDataReader reader = loginCmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Populate UserSession variables directly from the matching database row
                                UserSession.UserId = Convert.ToInt32(reader["UserId"]);
                                UserSession.Username = reader["Username"].ToString();
                                UserSession.FullName = reader["FullName"] != DBNull.Value ? reader["FullName"].ToString() : "";
                                UserSession.Email = reader["Email"] != DBNull.Value ? reader["Email"].ToString() : "";
                                UserSession.Phone = reader["Phone"] != DBNull.Value ? reader["Phone"].ToString() : "";
                                UserSession.Birthday = reader["Birthday"] != DBNull.Value ? reader["Birthday"].ToString() : "";
                                UserSession.PhotoPath = reader["PhotoPath"] != DBNull.Value ? reader["PhotoPath"].ToString() : "";

                                // Convert the saved image file path back to a usable GDI+ Image object
                                if (!string.IsNullOrWhiteSpace(UserSession.PhotoPath) && System.IO.File.Exists(UserSession.PhotoPath))
                                {
                                    UserSession.UserProfilePic = Image.FromFile(UserSession.PhotoPath);
                                }
                                else
                                {
                                    UserSession.UserProfilePic = null;
                                }

                                // ROUTING CHECK: Bypass PersonalInfo setup if they have already filled out their details
                                if (string.IsNullOrEmpty(UserSession.FullName))
                                {
                                    // Empty FullName means setup was incomplete; route them to PersonalInfo
                                    MessageBox.Show("Please complete your profile details first.", "Setup Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    PersonalInfo setupWindow = new PersonalInfo();
                                    setupWindow.Show();
                                    this.Hide();
                                }
                                else
                                {
                                    // Profile already exists! Skip PersonalInfo and proceed directly to Home (Dashboard)
                                    MessageBox.Show("Welcome back, " + UserSession.Username + "!", "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    Home homeWindow = new Home();
                                    homeWindow.Show();
                                    this.Hide();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid Username or Password.", "Authentication Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
        }

        private void lbl_welcome_Click(object sender, EventArgs e)
        {

        }

        private void panel_login_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}