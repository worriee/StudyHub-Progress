﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // Required for SQL connection and command classes

namespace StudyHub
{
    public partial class AddProject : Form
    {
        // Properties used to hold and pass the newly added project data back to the Dashboard
        public string ProjectTitle { get; set; }
        public string ProjectNote { get; set; }
        public string ProjectDeadline { get; set; }
        public string ProjectFileName { get; set; }
        // ADDED: Holds and transfers the selected year level back to the dashboard
        public string ProjectYearLevel { get; set; }

        // Constructor: Initializes form components and checks if Dark Mode is active
        public AddProject(bool isDarkMode)
        {
            InitializeComponent();

            if (isDarkMode)
            {
                ApplyDarkMode();
            }
        }

        // Sets up dark theme styling configurations for the entire form window
        private void ApplyDarkMode()
        {
            this.BackColor = Color.FromArgb(32, 32, 32); // Main window background

            // Updates label colors to match the dark theme
            label1.ForeColor = Color.White;
            lbl_notes.ForeColor = Color.White;
            lbl_upload.ForeColor = Color.White;
            lbl_filename.ForeColor = Color.LightGray;
            lbl_ddl.ForeColor = Color.White;

            // Sets input background and borders to dark gray with white text
            txtbox_title.BackColor = Color.FromArgb(45, 45, 45);
            txtbox_title.ForeColor = Color.White;
            txtbox_title.BorderStyle = BorderStyle.FixedSingle;

            txtbox_notes.BackColor = Color.FromArgb(45, 45, 45);
            txtbox_notes.ForeColor = Color.White;
            txtbox_notes.BorderStyle = BorderStyle.FixedSingle;

            pnl_upload.BackColor = Color.FromArgb(40, 40, 40); // Upload area container

            // Sets button color states
            btn_addproject.BackColor = Color.FromArgb(60, 60, 60);
            btn_addproject.ForeColor = Color.White;

            btn_cancel.BackColor = Color.DarkRed;
            btn_cancel.ForeColor = Color.White;

            // Applies Dark Mode styling parameters to the year level ComboBox
            cb_yearlevel.FlatStyle = FlatStyle.Flat;
            cb_yearlevel.BackColor = Color.FromArgb(45, 45, 45);
            cb_yearlevel.ForeColor = Color.White;
        }

        // Action when clicking the upload cloud icon to browse files
        private void pb_upload_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Select Project File";
            openFileDialog1.Filter = "Project Files (*.pdf;*.docx;*.zip)|*.pdf;*.docx;*.zip|All files (*.*)|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lbl_filename.Text = "Selected: " + openFileDialog1.SafeFileName;
                ProjectFileName = openFileDialog1.SafeFileName; // Capture raw filename for SQL insertion
                lbl_filename.ForeColor = Color.Gray;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        // Draws the custom dashed border layout inside the file upload panel area
        private void pnl_upload_Paint(object sender, PaintEventArgs e)
        {
            Pen dashedPen = new Pen(Color.Gray, 2);
            dashedPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            e.Graphics.DrawRectangle(dashedPen, 10, 10, pnl_upload.Width - 20, pnl_upload.Height - 20);
        }

        // Action when clicking anywhere inside the upload panel background area to browse files
        private void pnl_upload_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Select Project File";
            openFileDialog1.Filter = "Project Files (*.pdf;*.docx;*.zip)|*.pdf;*.docx;*.zip|All files (*.*)|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lbl_filename.Text = "Selected: " + openFileDialog1.SafeFileName;
                ProjectFileName = openFileDialog1.SafeFileName; // Capture raw filename for SQL insertion
                lbl_filename.ForeColor = Color.Gray;
            }
        }

        // Clears out the default helper text when user clicks inside the notes text box
        private void txtbox_notes_Enter(object sender, EventArgs e)
        {
            if (txtbox_notes.Text == "Add any project details or specific notes here...")
            {
                txtbox_notes.Text = "";
                txtbox_notes.ForeColor = Color.Gray;
            }
        }

        // Restores placeholder help text if the notes text box is left empty on focus loss
        private void txtbox_notes_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtbox_notes.Text))
            {
                txtbox_notes.Text = "Add any project details, links, or specific notes here...";
                txtbox_notes.ForeColor = Color.Black;
            }
        }

        // Validates all input fields and inserts the new record into transHistory.mdf
        private void btn_addproject_Click(object sender, EventArgs e)
        {
            // Validation 1: Require title entry before submitting
            if (string.IsNullOrWhiteSpace(txtbox_title.Text))
            {
                MessageBox.Show("Project Title is required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validation 2: Ensure a Year Level is selected
            if (cb_yearlevel.SelectedIndex == -1)
            {
                MessageBox.Show("Please select your Year Level!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validation 3: Ensure the deadline selected is not in the past
            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("The deadline cannot be in the past!", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Prevent system from saving actual helper placeholders as legitimate project notes
            string finalNotes = "";
            if (txtbox_notes.Text != "Add any project details or specific notes here..." && txtbox_notes.Text != "Add any project details, links, or specific notes here...")
            {
                finalNotes = txtbox_notes.Text;
            }

            // Assign clean inputs directly to form's properties
            ProjectTitle = txtbox_title.Text;
            ProjectNote = finalNotes;
            ProjectDeadline = dateTimePicker1.Value.ToShortDateString();

            // FIXED: Assigns ComboBox year level value directly to property to prevent "N/A" dashboard bugs
            ProjectYearLevel = cb_yearlevel.SelectedItem != null ? cb_yearlevel.SelectedItem.ToString() : "N/A";

            try
            {
                // Connect to transHistory.mdf and push raw project details to UserControl table
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();

                    // FIXED: Appended 'YearLevel' column name and parameter target to insertion string
                    string query = "INSERT INTO UserControl (UserId, FullName, ProjectTitle, Deadline, FileAttached, Notes, YearLevel) " +
                                   "VALUES (@UserId, @FullName, @ProjectTitle, @Deadline, @FileAttached, @Notes, @YearLevel)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Safely bind active user parameters to query arguments
                        cmd.Parameters.AddWithValue("@UserId", UserSession.UserId);
                        cmd.Parameters.AddWithValue("@FullName", UserSession.FullName);
                        cmd.Parameters.AddWithValue("@ProjectTitle", ProjectTitle);
                        cmd.Parameters.AddWithValue("@Deadline", ProjectDeadline);
                        cmd.Parameters.AddWithValue("@FileAttached", (object)ProjectFileName ?? DBNull.Value); // Handles blank file scenarios
                        cmd.Parameters.AddWithValue("@Notes", (object)ProjectNote ?? DBNull.Value);         // Handles blank notes scenarios

                        // FIXED: Saves the selected year level string parameter securely to database
                        cmd.Parameters.AddWithValue("@YearLevel", ProjectYearLevel);

                        cmd.ExecuteNonQuery(); // Execute SQL database query
                    }
                }

                MessageBox.Show("Project successfully added!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Keep form open if query fails
            }

            this.DialogResult = DialogResult.OK; // Set DialogResult to trigger Dashboard reload
            this.Close();
        }

        // Detects dragged objects and switches cursor layout if items are valid files
        private void pnl_upload_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
                pnl_upload.BackColor = Color.LightGray;
            }
        }

        // Extracts the dropped file name and assigns it to your global project variable
        private void pnl_upload_DragDrop(object sender, DragEventArgs e)
        {
            pnl_upload.BackColor = Color.Gray;
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            if (files.Length > 0)
            {
                string filePath = files[0];
                string fileName = System.IO.Path.GetFileName(filePath); // Strip directory paths, keep filename only

                lbl_filename.Text = "Selected: " + fileName;
                ProjectFileName = fileName; // Save file property
                lbl_filename.ForeColor = Color.Black;
            }
        }

        // Closes form window directly without triggering data insertion
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Handles file browsing via the dedicated "Upload File" browse button click event
        private void btn_upload_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Select Project File";
            openFileDialog1.Filter = "Project Files (*.pdf;*.docx;*.zip)|*.pdf;*.docx;*.zip|All files (*.*)|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lbl_filename.Text = "Selected: " + openFileDialog1.SafeFileName;
                ProjectFileName = openFileDialog1.SafeFileName; // Keep filename for database insertion
                lbl_filename.ForeColor = Color.Black;
            }
        }

        private void lbl_notes_Click(object sender, EventArgs e)
        {

        }

        private void AddProject_Load(object sender, EventArgs e)
        {

        }

        private void txtbox_notes_TextChanged(object sender, EventArgs e)
        {

        }
    }
}