﻿namespace StudyHub
{
    partial class DashboardCard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProjectTitle = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnAccept = new System.Windows.Forms.Button();
            this.lbldeadline = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lbl_file = new System.Windows.Forms.Label();
            this.lbl_yearlevel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblProjectTitle
            // 
            this.lblProjectTitle.AutoSize = true;
            this.lblProjectTitle.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectTitle.Location = new System.Drawing.Point(3, 47);
            this.lblProjectTitle.Name = "lblProjectTitle";
            this.lblProjectTitle.Size = new System.Drawing.Size(50, 22);
            this.lblProjectTitle.TabIndex = 0;
            this.lblProjectTitle.Text = "Title:";
            this.lblProjectTitle.Click += new System.EventHandler(this.lblProjectTitle_Click);
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(24, 12);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(54, 18);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Name:";
            this.lblUser.Click += new System.EventHandler(this.lblUser_Click);
            // 
            // btnAccept
            // 
            this.btnAccept.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.btnAccept.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccept.Location = new System.Drawing.Point(363, 147);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(90, 23);
            this.btnAccept.TabIndex = 2;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = false;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // lbldeadline
            // 
            this.lbldeadline.AutoSize = true;
            this.lbldeadline.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeadline.Location = new System.Drawing.Point(4, 70);
            this.lbldeadline.Name = "lbldeadline";
            this.lbldeadline.Size = new System.Drawing.Size(51, 14);
            this.lbldeadline.TabIndex = 3;
            this.lbldeadline.Text = "Deadline:";
            this.lbldeadline.Click += new System.EventHandler(this.lbldeadline_Click);
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(4, 102);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(41, 16);
            this.lblNote.TabIndex = 4;
            this.lblNote.Text = "Note:";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(475, 180);
            this.shapeContainer1.TabIndex = 5;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = -2;
            this.lineShape1.X2 = 479;
            this.lineShape1.Y1 = 42;
            this.lineShape1.Y2 = 42;
            // 
            // lbl_file
            // 
            this.lbl_file.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_file.Location = new System.Drawing.Point(4, 147);
            this.lbl_file.Name = "lbl_file";
            this.lbl_file.Size = new System.Drawing.Size(353, 33);
            this.lbl_file.TabIndex = 6;
            this.lbl_file.Text = "Attached:";
            // 
            // lbl_yearlevel
            // 
            this.lbl_yearlevel.AutoSize = true;
            this.lbl_yearlevel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_yearlevel.Location = new System.Drawing.Point(323, 12);
            this.lbl_yearlevel.Name = "lbl_yearlevel";
            this.lbl_yearlevel.Size = new System.Drawing.Size(84, 18);
            this.lbl_yearlevel.TabIndex = 7;
            this.lbl_yearlevel.Text = "Year Level:";
            this.lbl_yearlevel.Click += new System.EventHandler(this.lbl_yearlevel_Click);
            // 
            // DashboardCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(210)))), ((int)(((byte)(188)))));
            this.Controls.Add(this.lbl_yearlevel);
            this.Controls.Add(this.lbl_file);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lbldeadline);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblProjectTitle);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "DashboardCard";
            this.Size = new System.Drawing.Size(475, 180);
            this.Load += new System.EventHandler(this.DashboardCard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProjectTitle;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Label lbldeadline;
        private System.Windows.Forms.Label lblNote;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Label lbl_file;
        private System.Windows.Forms.Label lbl_yearlevel;

    }
}
