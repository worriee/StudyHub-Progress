﻿namespace StudyHub
{
    partial class AddProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ddl = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbl_upload = new System.Windows.Forms.Label();
            this.pnl_upload = new System.Windows.Forms.Panel();
            this.pb_upload = new System.Windows.Forms.PictureBox();
            this.lbl_filename = new System.Windows.Forms.Label();
            this.lbl_notes = new System.Windows.Forms.Label();
            this.txtbox_notes = new System.Windows.Forms.TextBox();
            this.btn_addproject = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbox_title = new System.Windows.Forms.TextBox();
            this.lbl_yearlvl = new System.Windows.Forms.Label();
            this.cb_yearlevel = new System.Windows.Forms.ComboBox();
            this.pnl_upload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_ddl
            // 
            this.lbl_ddl.AutoSize = true;
            this.lbl_ddl.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_ddl.Location = new System.Drawing.Point(9, 7);
            this.lbl_ddl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_ddl.Name = "lbl_ddl";
            this.lbl_ddl.Size = new System.Drawing.Size(123, 17);
            this.lbl_ddl.TabIndex = 0;
            this.lbl_ddl.Text = "Select Project Deadline:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(9, 28);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // lbl_upload
            // 
            this.lbl_upload.AutoSize = true;
            this.lbl_upload.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_upload.Location = new System.Drawing.Point(9, 124);
            this.lbl_upload.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_upload.Name = "lbl_upload";
            this.lbl_upload.Size = new System.Drawing.Size(82, 17);
            this.lbl_upload.TabIndex = 2;
            this.lbl_upload.Text = "Upload Project:";
            // 
            // pnl_upload
            // 
            this.pnl_upload.AllowDrop = true;
            this.pnl_upload.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_upload.Controls.Add(this.pb_upload);
            this.pnl_upload.Location = new System.Drawing.Point(12, 144);
            this.pnl_upload.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_upload.Name = "pnl_upload";
            this.pnl_upload.Size = new System.Drawing.Size(225, 81);
            this.pnl_upload.TabIndex = 3;
            this.pnl_upload.Click += new System.EventHandler(this.pnl_upload_Click);
            this.pnl_upload.DragDrop += new System.Windows.Forms.DragEventHandler(this.pnl_upload_DragDrop);
            this.pnl_upload.DragEnter += new System.Windows.Forms.DragEventHandler(this.pnl_upload_DragEnter);
            this.pnl_upload.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_upload_Paint);
            // 
            // pb_upload
            // 
            this.pb_upload.Image = global::StudyHub.Properties.Resources.upload;
            this.pb_upload.Location = new System.Drawing.Point(79, 16);
            this.pb_upload.Margin = new System.Windows.Forms.Padding(2);
            this.pb_upload.Name = "pb_upload";
            this.pb_upload.Size = new System.Drawing.Size(68, 49);
            this.pb_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_upload.TabIndex = 4;
            this.pb_upload.TabStop = false;
            this.pb_upload.Click += new System.EventHandler(this.pb_upload_Click);
            // 
            // lbl_filename
            // 
            this.lbl_filename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_filename.Location = new System.Drawing.Point(10, 228);
            this.lbl_filename.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_filename.Name = "lbl_filename";
            this.lbl_filename.Size = new System.Drawing.Size(233, 63);
            this.lbl_filename.TabIndex = 4;
            this.lbl_filename.Text = "No file chosen";
            this.lbl_filename.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_notes
            // 
            this.lbl_notes.AutoSize = true;
            this.lbl_notes.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_notes.Location = new System.Drawing.Point(9, 290);
            this.lbl_notes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_notes.Name = "lbl_notes";
            this.lbl_notes.Size = new System.Drawing.Size(117, 17);
            this.lbl_notes.TabIndex = 5;
            this.lbl_notes.Text = "Comments and Notes:";
            this.lbl_notes.Click += new System.EventHandler(this.lbl_notes_Click);
            // 
            // txtbox_notes
            // 
            this.txtbox_notes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.txtbox_notes.Location = new System.Drawing.Point(12, 310);
            this.txtbox_notes.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_notes.Multiline = true;
            this.txtbox_notes.Name = "txtbox_notes";
            this.txtbox_notes.Size = new System.Drawing.Size(226, 78);
            this.txtbox_notes.TabIndex = 6;
            this.txtbox_notes.Text = "Add any project details or specific notes here...";
            this.txtbox_notes.TextChanged += new System.EventHandler(this.txtbox_notes_TextChanged);
            this.txtbox_notes.Enter += new System.EventHandler(this.txtbox_notes_Enter);
            this.txtbox_notes.Leave += new System.EventHandler(this.txtbox_notes_Leave);
            // 
            // btn_addproject
            // 
            this.btn_addproject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.btn_addproject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_addproject.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addproject.Location = new System.Drawing.Point(34, 402);
            this.btn_addproject.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addproject.Name = "btn_addproject";
            this.btn_addproject.Size = new System.Drawing.Size(76, 27);
            this.btn_addproject.TabIndex = 7;
            this.btn_addproject.Text = "Add Project";
            this.btn_addproject.UseVisualStyleBackColor = false;
            this.btn_addproject.Click += new System.EventHandler(this.btn_addproject_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Location = new System.Drawing.Point(134, 402);
            this.btn_cancel.Margin = new System.Windows.Forms.Padding(2);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(76, 27);
            this.btn_cancel.TabIndex = 8;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.label1.Location = new System.Drawing.Point(9, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Project Title:";
            // 
            // txtbox_title
            // 
            this.txtbox_title.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtbox_title.Location = new System.Drawing.Point(9, 68);
            this.txtbox_title.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_title.Multiline = true;
            this.txtbox_title.Name = "txtbox_title";
            this.txtbox_title.Size = new System.Drawing.Size(229, 54);
            this.txtbox_title.TabIndex = 10;
            // 
            // lbl_yearlvl
            // 
            this.lbl_yearlvl.AutoSize = true;
            this.lbl_yearlvl.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_yearlvl.Location = new System.Drawing.Point(143, 7);
            this.lbl_yearlvl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_yearlvl.Name = "lbl_yearlvl";
            this.lbl_yearlvl.Size = new System.Drawing.Size(64, 17);
            this.lbl_yearlvl.TabIndex = 11;
            this.lbl_yearlvl.Text = "Year Level:";
            // 
            // cb_yearlevel
            // 
            this.cb_yearlevel.FormattingEnabled = true;
            this.cb_yearlevel.Items.AddRange(new object[] {
            "1st Year",
            "2nd Year",
            "3rd Year",
            "4th Year"});
            this.cb_yearlevel.Location = new System.Drawing.Point(146, 27);
            this.cb_yearlevel.Name = "cb_yearlevel";
            this.cb_yearlevel.Size = new System.Drawing.Size(91, 21);
            this.cb_yearlevel.TabIndex = 12;
            // 
            // AddProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(249)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(266, 456);
            this.Controls.Add(this.cb_yearlevel);
            this.Controls.Add(this.lbl_yearlvl);
            this.Controls.Add(this.txtbox_title);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_addproject);
            this.Controls.Add(this.txtbox_notes);
            this.Controls.Add(this.lbl_notes);
            this.Controls.Add(this.lbl_filename);
            this.Controls.Add(this.pnl_upload);
            this.Controls.Add(this.lbl_upload);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbl_ddl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AddProject";
            this.Text = "AddProject";
            this.Load += new System.EventHandler(this.AddProject_Load);
            this.pnl_upload.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ddl;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbl_upload;
        private System.Windows.Forms.Panel pnl_upload;
        private System.Windows.Forms.PictureBox pb_upload;
        private System.Windows.Forms.Label lbl_filename;
        private System.Windows.Forms.Label lbl_notes;
        private System.Windows.Forms.TextBox txtbox_notes;
        private System.Windows.Forms.Button btn_addproject;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbox_title;
        private System.Windows.Forms.Label lbl_yearlvl;
        private System.Windows.Forms.ComboBox cb_yearlevel;
    }
}