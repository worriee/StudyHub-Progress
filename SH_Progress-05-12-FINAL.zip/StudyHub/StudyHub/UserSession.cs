﻿using System;
using System.Drawing;

namespace StudyHub
{
    public static class UserSession
    {
        // Tracks the unique database ID for the logged-in user
        public static int UserId;
        public static string Username;
        public static string FullName;
        public static string Birthday;
        public static string Email;
        public static string Phone;

        // ADDED: Stores the file path of the profile image (fixes 'PhotoPath' compile errors)
        public static string PhotoPath;

        // Stores the actual visual image object loaded from the PhotoPath
        public static Image UserProfilePic;

        // Resets all session variables back to blank during a logout sequence
        public static void Clear()
        {
            UserId = 0;
            Username = null;
            FullName = null;
            Birthday = null;
            Email = null;
            Phone = null;

            // ADDED: Resets the stored file path back to null upon logging out
            PhotoPath = null;

            UserProfilePic = null;
        }
    }
}