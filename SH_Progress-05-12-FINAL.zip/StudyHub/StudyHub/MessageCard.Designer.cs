﻿namespace StudyHub
{
    partial class MessageCard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lblMsgcard = new System.Windows.Forms.Label();
            this.lbl_user = new System.Windows.Forms.Label();
            this.lbl_file = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.btnFullscreen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = -3;
            this.lineShape1.X2 = 478;
            this.lineShape1.Y1 = 42;
            this.lineShape1.Y2 = 42;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(633, 222);
            this.shapeContainer1.TabIndex = 4;
            this.shapeContainer1.TabStop = false;
            // 
            // lblMsgcard
            // 
            this.lblMsgcard.AutoSize = true;
            this.lblMsgcard.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgcard.Location = new System.Drawing.Point(23, 17);
            this.lblMsgcard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMsgcard.Name = "lblMsgcard";
            this.lblMsgcard.Size = new System.Drawing.Size(169, 24);
            this.lblMsgcard.TabIndex = 5;
            this.lblMsgcard.Text = "SWAP REQUEST";
            // 
            // lbl_user
            // 
            this.lbl_user.AutoSize = true;
            this.lbl_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.Location = new System.Drawing.Point(24, 63);
            this.lbl_user.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(57, 23);
            this.lbl_user.TabIndex = 6;
            this.lbl_user.Text = "User:";
            // 
            // lbl_file
            // 
            this.lbl_file.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_file.Location = new System.Drawing.Point(4, 177);
            this.lbl_file.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_file.Name = "lbl_file";
            this.lbl_file.Size = new System.Drawing.Size(397, 41);
            this.lbl_file.TabIndex = 7;
            this.lbl_file.Text = "Attached:";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(24, 87);
            this.lblNote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(47, 19);
            this.lblNote.TabIndex = 8;
            this.lblNote.Text = "Note:";
            // 
            // btnFullscreen
            // 
            this.btnFullscreen.BackgroundImage = global::StudyHub.Properties.Resources.fullscreen;
            this.btnFullscreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFullscreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFullscreen.Location = new System.Drawing.Point(579, 12);
            this.btnFullscreen.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFullscreen.Name = "btnFullscreen";
            this.btnFullscreen.Size = new System.Drawing.Size(39, 28);
            this.btnFullscreen.TabIndex = 9;
            this.btnFullscreen.UseVisualStyleBackColor = true;
            // 
            // MessageCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(210)))), ((int)(((byte)(188)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Controls.Add(this.btnFullscreen);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lbl_file);
            this.Controls.Add(this.lbl_user);
            this.Controls.Add(this.lblMsgcard);
            this.Controls.Add(this.shapeContainer1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MessageCard";
            this.Size = new System.Drawing.Size(633, 222);
            this.Load += new System.EventHandler(this.MessageCard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label lblMsgcard;
        private System.Windows.Forms.Label lbl_user;
        private System.Windows.Forms.Label lbl_file;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnFullscreen;
    }
}
