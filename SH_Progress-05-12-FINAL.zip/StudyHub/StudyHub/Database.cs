﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace StudyHub
{
    public static class Database
    {
        public static SqlConnection GetConnection()
        {
            string connString = ConfigurationManager.ConnectionStrings["LoginDetailsConnection"].ConnectionString;
            return new SqlConnection(connString);
        }

        public static SqlConnection GetTransConnection()
        {
            string connString = ConfigurationManager.ConnectionStrings["DashboardDBConnection"].ConnectionString;
            return new SqlConnection(connString);
        }
    }
}