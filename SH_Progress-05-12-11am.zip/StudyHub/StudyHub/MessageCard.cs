﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class MessageCard : UserControl
    {
        // Cache variables to identify the chat context when launching the workspace
        private string requesterUsername = "";
        private string projectTitle = "";
        private string projectNotes = "";
        private string attachedFile = "";

        public MessageCard()
        {
            InitializeComponent();

            // FIXED: Programmatically bind the click event so it is guaranteed to fire regardless of designer bugs
            if (this.btnFullscreen != null)
            {
                this.btnFullscreen.Click += new System.EventHandler(this.btnFullscreen_Click);
            }
        }

        // Binds raw row data from the database directly to your card's visual controls
        public void SetMessageDetails(string senderFullName, string senderUsername, string note, string filename, string title, string status)
        {
            this.requesterUsername = senderUsername;
            this.projectTitle = title;
            this.projectNotes = note;
            this.attachedFile = filename;

            // Use ToUpper() to ensure the comparison works even if DB casing is different
            // Inside MessageCard.cs
            string currentStatus = status.Trim().ToUpper();

            if (currentStatus == "COMPLETED")
            {
                lblMsgcard.Text = "SWAP REQUEST: COMPLETED";
                lblMsgcard.ForeColor = Color.Green;
            }
            else if (currentStatus == "CANCELLED")
            {
                lblMsgcard.Text = "SWAP REQUEST: CANCELLED";
                lblMsgcard.ForeColor = Color.Red;
            }
            else
            {
                lblMsgcard.Text = "SWAP REQUEST: PENDING";
                lblMsgcard.ForeColor = Color.Black;
            }

            lbl_user.Text = string.Format("User: {0} wants to swap projects with you.", senderFullName);
            lblNote.Text = "Note: " + note;
            lbl_file.Text = "Attached: " + filename;
        }

        // Triggers the collaborative chat workspace inside Home.cs
        private void btnFullscreen_Click(object sender, EventArgs e)
        {
            // FIXED: Use FindForm() instead of Application.OpenForms to safely locate the parent Home container form
            Home homeForm = this.FindForm() as Home;
            if (homeForm != null)
            {
                // Passes stored database fields straight into the chat view initializer
                homeForm.OpenChatRoom(requesterUsername, projectTitle, projectNotes, attachedFile);
            }
        }

        private void btnApproved_Click(object sender, EventArgs e)
        {
            // Placeholder: approve transaction logic
        }

        private void btnDecline_Click(object sender, EventArgs e)
        {
            // Placeholder: decline transaction logic
        }

        private void MessageCard_Load(object sender, EventArgs e)
        {

        }
    }
}