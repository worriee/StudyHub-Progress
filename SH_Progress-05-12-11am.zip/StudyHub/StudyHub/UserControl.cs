﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudyHub
{
    public partial class DashboardCard : UserControl
    {
        // Fields to cache clean parameters for inserting into transHistory
        private string rawProjectTitle = "";
        private string rawProjectDeadline = "";

        // Removed the "= "N/A"" inline initializer to make it compile on older C# versions
        public string YearLevel { get; private set; }

        public DashboardCard()
        {
            InitializeComponent();
            YearLevel = "N/A"; // Assigned default value inside constructor for C# 5 compatibility
        }

        public DashboardCard(bool isDarkMode)
        {
            InitializeComponent();
            YearLevel = "N/A"; // Assigned default value inside constructor for C# 5 compatibility
            ApplyDarkMode(isDarkMode);
        }

        // Binds all project parameters to their respective text labels
        public void SetProjectDetails(string name, string deadline, string title, string note, string filename, string yearLevel)
        {
            lblUser.Text = "Name: " + name;
            lbldeadline.Text = "Deadline: " + deadline;
            lblProjectTitle.Text = "Title: " + title;
            lblNote.Text = "Note: " + note;
            lbl_file.Text = "Attached: " + filename;
            lbl_yearlevel.Text = "Year Level: " + yearLevel;

            this.YearLevel = yearLevel; // Saves the year level string inside our public property
            rawProjectTitle = title;
            rawProjectDeadline = deadline;
        }

        // Switches styling themes of labels inside the card layout
        public void ApplyDarkMode(bool isDarkMode)
        {
            if (isDarkMode)
            {
                this.BackColor = Color.FromArgb(84, 84, 84); // Dark background for the card
                lblNote.ForeColor = Color.White;
                lblProjectTitle.ForeColor = Color.White;
                lbldeadline.ForeColor = Color.White;
                lblUser.ForeColor = Color.White;
                lbl_file.ForeColor = Color.White;
                lbl_yearlevel.ForeColor = Color.White; // Updates the year level label to white in Dark Mode

                lineShape1.BorderColor = Color.White;
                btnAccept.BackColor = Color.FromArgb(66, 66, 66);
                btnAccept.ForeColor = Color.White;
            }
            else
            {
                // Light Mode Reset
                this.BackColor = Color.FromArgb(218, 210, 188);
                lblNote.ForeColor = Color.Black;
                lblProjectTitle.ForeColor = Color.Black;
                lbldeadline.ForeColor = Color.Black;
                lblUser.ForeColor = Color.Black;
                lbl_file.ForeColor = Color.Black;
                lbl_yearlevel.ForeColor = Color.Black; // Updates the year level label to black in Light Mode

                lineShape1.BorderColor = Color.Black;
                btnAccept.BackColor = Color.FromArgb(163, 177, 138);
                btnAccept.ForeColor = Color.Black;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbldeadline_Click(object sender, EventArgs e)
        {

        }

        private void DashboardCard_Load(object sender, EventArgs e)
        {

        }

        // Handles accepting a project, saving to SQL, and refreshing the transaction grid
        private void btnAccept_Click(object sender, EventArgs e)
        {
            // Confirm action before writing to database files
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to accept this project?", "Confirm Acceptance", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    string uploaderFullName = lblUser.Text.Replace("Name: ", "").Trim();
                    string ownerUsername = "";

                    // FIXED 1: Look up project owner's active Username in loginDetails table using FullName to double-insert safely
                    using (SqlConnection loginConn = Database.GetConnection())
                    {
                        loginConn.Open();
                        string findOwnerQuery = "SELECT Username FROM loginDetails WHERE FullName = @FullName";
                        using (SqlCommand findCmd = new SqlCommand(findOwnerQuery, loginConn))
                        {
                            findCmd.Parameters.AddWithValue("@FullName", uploaderFullName);
                            object res = findCmd.ExecuteScalar();
                            if (res != null)
                            {
                                ownerUsername = res.ToString();
                            }
                        }
                    }

                    // FIXED 2: Open transaction SQL pipeline and record row entries for BOTH users
                    using (SqlConnection conn = Database.GetTransConnection())
                    {
                        conn.Open();

                        // 2a. Insert transaction row for the Requester (the logged-in user who is accepting)
                        string queryRequester = "INSERT INTO transHistory (Username, ProjectTitle, Deadline, Status) VALUES (@Username, @ProjectTitle, @Deadline, @Status)";
                        using (SqlCommand cmd = new SqlCommand(queryRequester, conn))
                        {
                            cmd.Parameters.AddWithValue("@Username", UserSession.Username);
                            cmd.Parameters.AddWithValue("@ProjectTitle", rawProjectTitle);
                            cmd.Parameters.AddWithValue("@Deadline", rawProjectDeadline);
                            cmd.Parameters.AddWithValue("@Status", "Pending");

                            int rowsInserted = cmd.ExecuteNonQuery();
                            //MessageBox.Show("Requester transaction rows inserted: " + rowsInserted);
                        }

                        // 2b. Insert transaction row for the Owner (the uploader) if it is a different account
                        if (!string.IsNullOrEmpty(ownerUsername) && !ownerUsername.Equals(UserSession.Username, StringComparison.OrdinalIgnoreCase))
                        {
                            string queryOwner = "INSERT INTO transHistory (Username, ProjectTitle, Deadline, Status) VALUES (@Username, @ProjectTitle, @Deadline, @Status)";
                            using (SqlCommand cmd = new SqlCommand(queryOwner, conn))
                            {
                                cmd.Parameters.AddWithValue("@Username", ownerUsername);
                                cmd.Parameters.AddWithValue("@ProjectTitle", rawProjectTitle);
                                cmd.Parameters.AddWithValue("@Deadline", rawProjectDeadline);
                                cmd.Parameters.AddWithValue("@Status", "Pending");

                                int ownerRowsInserted = cmd.ExecuteNonQuery();
                                //MessageBox.Show("Owner transaction rows inserted: " + ownerRowsInserted);
                            }
                        }
                    }

                    MessageBox.Show("Project accepted! It is now recorded in your transaction history as Pending.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Find the open instance of your Home form and refresh its grid dynamically
                    Home homeForm = Application.OpenForms["Home"] as Home;
                    if (homeForm != null)
                    {
                        homeForm.LoadTransactionHistory(); // Triggers your transaction grid refresh
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void lblProjectTitle_Click(object sender, EventArgs e)
        {

        }

        private void lbl_yearlevel_Click(object sender, EventArgs e)
        {

        }

        private void lblUser_Click(object sender, EventArgs e)
        {

        }
    }
}