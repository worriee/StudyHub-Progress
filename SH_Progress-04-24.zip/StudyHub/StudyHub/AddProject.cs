﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class AddProject : Form
    {
        public string ProjectTitle { get; set; }
        public string ProjectNote { get; set; }
        public string ProjectDeadline { get; set; }
        public string ProjectFileName { get; set; }

        public AddProject(bool isDarkMode)
        {
            InitializeComponent();

            if (isDarkMode)
            {
                ApplyDarkMode();
            }
        }

        private void ApplyDarkMode()
        {
            this.BackColor = Color.FromArgb(30, 30, 30);

            foreach (Control c in this.Controls)
            {
                if (c is Label && c.Parent == this)
                {
                    c.ForeColor = Color.White;
                }
            }
        }

        private void pb_upload_Click(object sender, EventArgs e)
        {
            // 1. Set the title of the window
            openFileDialog1.Title = "Select Project File";

            // 2. Filter what files the user can see (optional but professional)
            openFileDialog1.Filter = "Project Files (*.pdf;*.docx;*.zip)|*.pdf;*.docx;*.zip|All files (*.*)|*.*";

            // 3. Open the File Manager and check if they picked a file
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // 4. Update the label to show the filename they chose
                lbl_filename.Text = "Selected: " + openFileDialog1.SafeFileName;
                ProjectFileName = openFileDialog1.SafeFileName;
                lbl_filename.ForeColor = Color.Gray;

                // You can also store the full path for SQL later
                // string fullPath = openFileDialog1.FileName;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pnl_upload_Paint(object sender, PaintEventArgs e)
        {
            // This draws the dashed border you see in modern UIs
            Pen dashedPen = new Pen(Color.Gray, 2);
            dashedPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

            // Draw it slightly inside the panel edges
            e.Graphics.DrawRectangle(dashedPen, 10, 10, pnl_upload.Width - 20, pnl_upload.Height - 20);
        }

        private void pnl_upload_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lbl_filename.Text = "Selected: " + openFileDialog1.SafeFileName;
            }
        }

        private void txtbox_notes_Enter(object sender, EventArgs e)
        {
            if (txtbox_notes.Text == "Add any project details or specific notes here...")
            {
                txtbox_notes.Text = "";
                txtbox_notes.ForeColor = Color.Gray;
            }
        }

        private void txtbox_notes_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtbox_notes.Text))
            {
                txtbox_notes.Text = "Add any project details, links, or specific notes here...";
                txtbox_notes.ForeColor = Color.Gray;
            }
        }

        private void btn_addproject_Click(object sender, EventArgs e)
        {
            // --- STEP 1: VALIDATION (The Filter) ---
            // Check if title is empty
            if (string.IsNullOrWhiteSpace(txtbox_title.Text))
            {
                MessageBox.Show("Project Title is required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Stops the code here so the window stays open
            }

            // Check if the date is in the past
            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("The deadline cannot be in the past!", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Stops the code here
            }

            // --- STEP 2: DATA PROCESSING (Only happens if validation passed) ---
            string finalNotes = "";
            if (txtbox_notes.Text != "Add any project details or specific notes here...")
            {
                finalNotes = txtbox_notes.Text;
            }

            // Assign to properties
            ProjectTitle = txtbox_title.Text;
            ProjectNote = finalNotes;
            ProjectDeadline = dateTimePicker1.Value.ToShortDateString();

            // --- STEP 3: FINISH ---
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void pnl_upload_DragEnter(object sender, DragEventArgs e)
        {
            // Check if the item being dragged is actually a file
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy; // Shows the [+] icon on the cursor
                pnl_upload.BackColor = Color.LightGray;
            }
        }

        private void pnl_upload_DragDrop(object sender, DragEventArgs e)
        {
            // Reset background color
            pnl_upload.BackColor = Color.Gray;

            // Get the path of the file(s) dropped
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            if (files.Length > 0)
            {
                // Get the full path (e.g., C:\Users\Documents\Project.pdf)
                string filePath = files[0];

                // Get just the filename (e.g., Project.pdf)
                string fileName = System.IO.Path.GetFileName(filePath);

                // Update your label to show the user it worked
                lbl_filename.Text = "Selected: " + fileName;
                lbl_filename.ForeColor = Color.Gray;

                // Tip: You can store 'filePath' in a variable to use for your SQL upload later
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            // 1. Set the title of the window
            openFileDialog1.Title = "Select Project File";

            // 2. Filter what files the user can see (optional but professional)
            openFileDialog1.Filter = "Project Files (*.pdf;*.docx;*.zip)|*.pdf;*.docx;*.zip|All files (*.*)|*.*";

            // 3. Open the File Manager and check if they picked a file
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // 4. Update the label to show the filename they chose
                lbl_filename.Text = "Selected: " + openFileDialog1.SafeFileName;
                lbl_filename.ForeColor = Color.Gray;

                // You can also store the full path for SQL later
                // string fullPath = openFileDialog1.FileName;
            }
        }

        private void lbl_notes_Click(object sender, EventArgs e)
        {

        }

        private void AddProject_Load(object sender, EventArgs e)
        {

        }
    }
}
