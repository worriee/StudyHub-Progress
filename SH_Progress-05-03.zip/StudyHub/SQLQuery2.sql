﻿INSERT INTO UserHistory ([User], ProjectTitle, DateFinished)
VALUES
('Laurence', 'Library System', '2026-05-01'),
('Laurence', 'Payroll System', '2026-05-05'),
('John', 'Enrollment System', '2026-05-07');