﻿CREATE TABLE UserHistory
(
    HistoryID INT IDENTITY(1,1) PRIMARY KEY,
    [User] VARCHAR(100),
    ProjectTitle VARCHAR(200),
    DateFinished DATE
);