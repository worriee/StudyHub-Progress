﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class Home : Form
    {
        // Your custom colors
        // Para rana sa sidebar
        Color activeColor = Color.FromArgb(250, 249, 238);   // Cream
        Color inactiveColor = Color.FromArgb(163, 177, 138); // Sage Green

        public Home()
        {
            InitializeComponent();
            ShowPage("Dashboard");
        }



        private void ShowPage(string pageName)
        {
            // 1. Hide all panels
            pnlDashboard.Visible = false;
            pnlAccount.Visible = false;
            pnlInbox.Visible = false;
            pnlHistory.Visible = false;

            // 2. Reset sidebar buttons to sage green
            btnDashboard.BackColor = inactiveColor;
            btnAccount.BackColor = inactiveColor;
            btnInbox.BackColor = inactiveColor;
            btnHistory.BackColor = inactiveColor;

            // Reset text colors
            btnDashboard.ForeColor = Color.Black;
            btnAccount.ForeColor = Color.Black;
            btnInbox.ForeColor = Color.Black;
            btnHistory.ForeColor = Color.Black;

            // 3. Dashboard Logic
            if (pageName == "Dashboard")
            {
                pnlDashboard.Visible = true;
                pnlDashboard.BringToFront(); //

                btnDashboard.BackColor = activeColor;
                btnDashboard.ForeColor = Color.Gray;

                btnAccount.BackColor = inactiveColor;
                btnAccount.ForeColor = Color.Black;


                // Keep the others inactive
                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            // 3. Account Logic
            else if (pageName == "Account")
            {
                pnlAccount.Visible = true;
                pnlAccount.BringToFront();

                btnAccount.BackColor = activeColor;
                btnAccount.ForeColor = Color.Gray;

                btnDashboard.BackColor = inactiveColor;
                btnDashboard.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            // 4. Inbox Logic
            else if (pageName == "Inbox")
            {
                pnlInbox.Visible = true;
                pnlInbox.BringToFront();
                btnInbox.BackColor = activeColor;
                btnInbox.ForeColor = Color.Gray;
            }
             // 5. History Logic
            else if (pageName == "History")
            {
                pnlHistory.Visible = true;
                pnlHistory.BringToFront();
                btnHistory.BackColor = activeColor;
                btnHistory.ForeColor = Color.Gray;
            }
        }

        // --- SIDEBAR CLICKS ---
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ShowPage("Dashboard");
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            ShowPage("Account");

            // 1. Show the Profile Panel (your existing code)
            pnlAccount.Visible = true;
            pnlDashboard.Visible = false; // and hide others...

            // 2. THE MISSING PIECE: Pull data from the backpack and put it in the labels
            // Use your actual label names from the Properties window!
            lblName.Text = "Name: " + UserSession.FullName;
            lblBday.Text = "Birthday: " + UserSession.Birthday;
            lblEmail.Text = "Email: " + UserSession.Email;
            lblPhone.Text = "Phone No. " + UserSession.Phone;

            // Check if there is a picture to show
            if (UserSession.UserProfilePic != null)
            {
                pbProfile.Image = UserSession.UserProfilePic;
                pbProfile.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void btnInbox_Click(object sender, EventArgs e)
        {
            ShowPage("Inbox");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            ShowPage("History");
        }

        // --- SEARCH LOGIC (Keeps the Designer happy!) ---
        private void pbSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.ToLower();
            // This filters the cards in your flpProjects
            foreach (Control card in flpProjects.Controls)
            {
                card.Visible = card.Name.ToLower().Contains(query);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            // Placeholder for search box logic
        }

        private void x(object sender, PaintEventArgs e)
        {
            // wala rapud ni ahak. LIKAY OG DOUBLE PRESS dol aron dili ma in ani kay diko kabaw unsaon pagremove
        }

        // --- EMERGENCY PLACEHOLDERS (DO NOT DELETE) ---
        private void Home_Load(object sender, EventArgs e) 
        {
            LoadHistoryData();
        }
        private void button1_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel_home_Paint(object sender, PaintEventArgs e) { }
        private void pnlAccount_Paint_1(object sender, PaintEventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }

        private void lineShape4_Click(object sender, EventArgs e)
        {
            
        }

        //dark themes
        bool isDarkMode = false; //toggle
        private void btn_darkmode_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;
            // 2. THE MISSING PIECE: Update all cards currently on the screen
            foreach (Control c in flpProjects.Controls)
            {
                // Try to treat the control as a DashboardCard
                DashboardCard card = c as DashboardCard;

                // If it successfully turned into a card (not null), run the theme code
                if (card != null)
                {
                    card.ApplyDarkMode(isDarkMode);
                }
            }

            if (isDarkMode)
            {
                // dark mode color
                this.BackColor = Color.FromArgb(102, 102, 102);
                pnlDashboard.BackColor = Color.FromArgb(102, 102, 102); 
                lblDashboard.ForeColor = Color.White;
                lblEmptyMessage.ForeColor = Color.White;
                pnlAccount.BackColor = Color.FromArgb(102, 102, 102);
                pnlInbox.BackColor = Color.FromArgb(102, 102, 102);
                pnlHistory.BackColor = Color.FromArgb(102, 102, 102);
                lblHistory.BackColor = Color.Transparent;
                lblHistory.ForeColor = Color.White;
                txtSearch.BackColor = Color.FromArgb(102, 102, 102);
                txtSearch.ForeColor = Color.White;
                lblMessage.ForeColor = Color.White;
                lblPhone.ForeColor = Color.White;
                lblBday.ForeColor = Color.White;
                lblEmail.ForeColor = Color.White;
                lblName.ForeColor = Color.White;
                lblUser.ForeColor = Color.White;

                cbLevels.FlatStyle = FlatStyle.Flat;
                cbLevels.BackColor = Color.FromArgb(102, 102, 102);
                cbLevels.ForeColor = Color.White;
                cbStatus.FlatStyle = FlatStyle.Flat;
                cbStatus.BackColor = Color.FromArgb(102, 102, 102);
                cbStatus.ForeColor = Color.White;

                // --- DataGridView: Transaction History ---
                dgv_transhistory.BackgroundColor = Color.FromArgb(45, 45, 45); // Dark Gray Background
                dgv_transhistory.GridColor = Color.FromArgb(60, 60, 60);       // Subtle grid lines

                // Rows and Cells
                dgv_transhistory.DefaultCellStyle.BackColor = Color.FromArgb(55, 55, 55); // Slightly lighter gray rows
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.White;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(80, 80, 80); // Highlight color
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.White;

                // Headers (The top row)
                dgv_transhistory.EnableHeadersVisualStyles = false;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70); // Header background
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                // --- Repeat for User History ---
                dgv_userhistory.BackgroundColor = Color.FromArgb(45, 45, 45);
                dgv_userhistory.DefaultCellStyle.BackColor = Color.FromArgb(55, 55, 55);
                dgv_userhistory.DefaultCellStyle.ForeColor = Color.White;
                dgv_userhistory.EnableHeadersVisualStyles = false;
                dgv_userhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
                dgv_userhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                // change btn icon to day
                btn_darkmode.BackgroundImage = Properties.Resources.light;
            }
            else
            {
                // default colors
                this.BackColor = Color.FromArgb(250, 249, 230);
                pnlDashboard.BackColor = Color.White;
                lblDashboard.ForeColor = Color.Black;
                lblEmptyMessage.ForeColor = Color.Black;
                pnlAccount.BackColor = Color.White;
                pnlInbox.BackColor = Color.White;
                pnlHistory.BackColor = Color.White;
                lblHistory.BackColor = Color.Transparent;
                lblHistory.ForeColor = Color.Black;
                txtSearch.BackColor = Color.White;
                txtSearch.ForeColor = Color.Black;
                lblMessage.ForeColor = Color.Black;
                lblPhone.ForeColor = Color.Black;
                lblBday.ForeColor = Color.Black;
                lblEmail.ForeColor = Color.Black;
                lblName.ForeColor = Color.Black;
                lblUser.ForeColor = Color.Black;
                cbLevels.FlatStyle = FlatStyle.Flat;
                cbLevels.BackColor = Color.White;
                cbLevels.ForeColor = Color.Black;

                cbStatus.FlatStyle = FlatStyle.Flat;
                cbStatus.BackColor = Color.White;
                cbStatus.ForeColor = Color.Black;

                // --- DataGridView: Transaction History ---
                dgv_transhistory.BackgroundColor = Color.FromArgb(240, 240, 240); // Light Gray Background
                dgv_transhistory.GridColor = Color.LightGray;

                // Rows and Cells
                dgv_transhistory.DefaultCellStyle.BackColor = Color.White;
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.Black;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(163, 177, 138); // Sage green highlight
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.Black;

                // Headers (Matches your sidebar green)
                dgv_transhistory.EnableHeadersVisualStyles = false;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(163, 177, 138);
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;

                dgv_userhistory.BackgroundColor = Color.FromArgb(240, 240, 240);
                dgv_userhistory.DefaultCellStyle.BackColor = Color.White;
                dgv_userhistory.DefaultCellStyle.ForeColor = Color.Black;
                dgv_userhistory.EnableHeadersVisualStyles = false;
                dgv_userhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(163, 177, 138);
                dgv_userhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
         
                btn_darkmode.BackgroundImage = Properties.Resources.night_mode;
            }
        }

        private void btnAddProject_Click(object sender, EventArgs e)
        {
            // 1. Create the window instance once
            using (AddProject window = new AddProject(isDarkMode))
            {
                // 2. Open it and check if the user clicked 'Add Project'
                if (window.ShowDialog() == DialogResult.OK)
                {
                    // 3. Create the visual card for your dashboard
                    DashboardCard newCard = new DashboardCard(isDarkMode);

                    // 4. Send the data from the 'window' backpack to the card
                    newCard.SetProjectDetails(
                        UserSession.FullName, //CARCEDO DAPAT ANG NAME ARI I FETCH NIYA GIKAN SA SQL USBA NI NGA LINE
                        window.ProjectDeadline,
                        window.ProjectTitle,
                        window.ProjectNote,
                        window.ProjectFileName
                    );

                    // 5. Add the card to your FlowLayoutPanel
                    flpProjects.Controls.Add(newCard);
                    lblEmptyMessage.Visible = false;
                }
            }
        }

        private void dgv_transhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_userhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {

                    string selectedProject = dgv_userhistory.Rows[e.RowIndex].Cells["Project Title"].Value.ToString();
                    string connString = @"Data Source=(localdb)\v11.0;Initial Catalog=StudentDB;Integrated Security=True";

                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        string query = "SELECT * FROM UserHistory WHERE ProjectTitle = @title";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@title", selectedProject);

                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            string user = reader["User"].ToString();
                            string date = Convert.ToDateTime(reader["DateFinished"]).ToShortDateString();

                            MessageBox.Show("Project: " + selectedProject + "\nCompleted by: " + user + "\nOn: " + date);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("SQL Error: " + ex.Message);
                }
            }

        }

        private void LoadHistoryData()
        {
            string connString = @"Data Source=(localdb)\v11.0;Initial Catalog=StudentDB;Integrated Security=True";
            string query = "SELECT [User], ProjectTitle, DateFinished FROM UserHistory";

            using (SqlConnection conn = new SqlConnection(connString))
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgv_userhistory.AutoGenerateColumns = false;
                    dgv_userhistory.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading Error: " + ex.Message);
                }
            }
        }



        private void btn_logout_Click(object sender, EventArgs e)
        {
            // 1. Ask for confirmation (UX Best Practice)
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Logout Confirmation",
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // 2. Clear the Session data
                // This ensures the next person who logs in doesn't see your info
                UserSession.FullName = null;
                UserSession.Email = null;
                UserSession.Phone = null;
                UserSession.Birthday = null;
                UserSession.UserProfilePic = null;

                // 3. Open the Login form
                Login window = new Login();
                window.Show();

                // 4. Close the current Dashboard
                this.Hide(); // Or this.Close(); depending on your Program.cs setup
            }
        }
    }
}