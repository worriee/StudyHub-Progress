﻿CREATE TABLE UserHistory (
    HistoryID INT PRIMARY KEY IDENTITY(1,1),
    [User] NVARCHAR(100) NOT NULL, -- Changed from Username
    ProjectTitle NVARCHAR(255) NOT NULL,
    DateFinished DATETIME DEFAULT GETDATE()
);