﻿namespace StudyHub
{
    partial class PersonalInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_note = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lbl_userEmail = new System.Windows.Forms.Label();
            this.txt_fullname = new System.Windows.Forms.TextBox();
            this.lbl_userFullname = new System.Windows.Forms.Label();
            this.dtp_userbd = new System.Windows.Forms.DateTimePicker();
            this.lbl_userbd = new System.Windows.Forms.Label();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.lbl_userPhone = new System.Windows.Forms.Label();
            this.btn_userInfo = new System.Windows.Forms.Button();
            this.progressTimer = new System.Windows.Forms.Timer(this.components);
            this.lbl_profile = new System.Windows.Forms.Label();
            this.panel_info = new System.Windows.Forms.Panel();
            this.pb_userimage = new System.Windows.Forms.PictureBox();
            this.panel_info.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_userimage)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_note
            // 
            this.lbl_note.AutoSize = true;
            this.lbl_note.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_note.Location = new System.Drawing.Point(140, 186);
            this.lbl_note.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_note.Name = "lbl_note";
            this.lbl_note.Size = new System.Drawing.Size(82, 17);
            this.lbl_note.TabIndex = 2;
            this.lbl_note.Text = "*upload a photo";
            // 
            // txt_email
            // 
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(64, 379);
            this.txt_email.Margin = new System.Windows.Forms.Padding(2);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(226, 26);
            this.txt_email.TabIndex = 4;
            // 
            // lbl_userEmail
            // 
            this.lbl_userEmail.AutoSize = true;
            this.lbl_userEmail.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_userEmail.Location = new System.Drawing.Point(61, 359);
            this.lbl_userEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_userEmail.Name = "lbl_userEmail";
            this.lbl_userEmail.Size = new System.Drawing.Size(39, 17);
            this.lbl_userEmail.TabIndex = 5;
            this.lbl_userEmail.Text = "Email:";
            // 
            // txt_fullname
            // 
            this.txt_fullname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fullname.Location = new System.Drawing.Point(64, 259);
            this.txt_fullname.Margin = new System.Windows.Forms.Padding(2);
            this.txt_fullname.Name = "txt_fullname";
            this.txt_fullname.Size = new System.Drawing.Size(226, 26);
            this.txt_fullname.TabIndex = 6;
            // 
            // lbl_userFullname
            // 
            this.lbl_userFullname.AutoSize = true;
            this.lbl_userFullname.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_userFullname.Location = new System.Drawing.Point(61, 239);
            this.lbl_userFullname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_userFullname.Name = "lbl_userFullname";
            this.lbl_userFullname.Size = new System.Drawing.Size(61, 17);
            this.lbl_userFullname.TabIndex = 7;
            this.lbl_userFullname.Text = "Full Name:";
            // 
            // dtp_userbd
            // 
            this.dtp_userbd.Location = new System.Drawing.Point(64, 323);
            this.dtp_userbd.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_userbd.Name = "dtp_userbd";
            this.dtp_userbd.Size = new System.Drawing.Size(84, 20);
            this.dtp_userbd.TabIndex = 8;
            // 
            // lbl_userbd
            // 
            this.lbl_userbd.AutoSize = true;
            this.lbl_userbd.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_userbd.Location = new System.Drawing.Point(61, 305);
            this.lbl_userbd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_userbd.Name = "lbl_userbd";
            this.lbl_userbd.Size = new System.Drawing.Size(51, 17);
            this.lbl_userbd.TabIndex = 9;
            this.lbl_userbd.Text = "Birthday:";
            // 
            // txt_phone
            // 
            this.txt_phone.Location = new System.Drawing.Point(190, 323);
            this.txt_phone.Margin = new System.Windows.Forms.Padding(2);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(100, 20);
            this.txt_phone.TabIndex = 10;
            // 
            // lbl_userPhone
            // 
            this.lbl_userPhone.AutoSize = true;
            this.lbl_userPhone.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lbl_userPhone.Location = new System.Drawing.Point(187, 305);
            this.lbl_userPhone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_userPhone.Name = "lbl_userPhone";
            this.lbl_userPhone.Size = new System.Drawing.Size(43, 17);
            this.lbl_userPhone.TabIndex = 11;
            this.lbl_userPhone.Text = "Phone:";
            // 
            // btn_userInfo
            // 
            this.btn_userInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(210)))), ((int)(((byte)(188)))));
            this.btn_userInfo.FlatAppearance.BorderSize = 0;
            this.btn_userInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_userInfo.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_userInfo.Location = new System.Drawing.Point(124, 422);
            this.btn_userInfo.Margin = new System.Windows.Forms.Padding(2);
            this.btn_userInfo.Name = "btn_userInfo";
            this.btn_userInfo.Size = new System.Drawing.Size(98, 28);
            this.btn_userInfo.TabIndex = 12;
            this.btn_userInfo.Text = "Done";
            this.btn_userInfo.UseVisualStyleBackColor = false;
            this.btn_userInfo.Click += new System.EventHandler(this.btn_userInfo_Click);
            this.btn_userInfo.Paint += new System.Windows.Forms.PaintEventHandler(this.btn_userInfo_Paint);
            // 
            // progressTimer
            // 
            this.progressTimer.Enabled = true;
            this.progressTimer.Interval = 50;
            this.progressTimer.Tick += new System.EventHandler(this.progressTimer_Tick);
            // 
            // lbl_profile
            // 
            this.lbl_profile.AutoSize = true;
            this.lbl_profile.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_profile.Location = new System.Drawing.Point(124, 28);
            this.lbl_profile.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_profile.Name = "lbl_profile";
            this.lbl_profile.Size = new System.Drawing.Size(114, 24);
            this.lbl_profile.TabIndex = 13;
            this.lbl_profile.Text = "Edit Profile";
            this.lbl_profile.Click += new System.EventHandler(this.lbl_profile_Click);
            // 
            // panel_info
            // 
            this.panel_info.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_info.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.panel_info.Controls.Add(this.pb_userimage);
            this.panel_info.Controls.Add(this.btn_userInfo);
            this.panel_info.Controls.Add(this.lbl_profile);
            this.panel_info.Controls.Add(this.lbl_userEmail);
            this.panel_info.Controls.Add(this.lbl_userPhone);
            this.panel_info.Controls.Add(this.txt_email);
            this.panel_info.Controls.Add(this.lbl_note);
            this.panel_info.Controls.Add(this.lbl_userbd);
            this.panel_info.Controls.Add(this.txt_phone);
            this.panel_info.Controls.Add(this.txt_fullname);
            this.panel_info.Controls.Add(this.lbl_userFullname);
            this.panel_info.Controls.Add(this.dtp_userbd);
            this.panel_info.Location = new System.Drawing.Point(271, 31);
            this.panel_info.Margin = new System.Windows.Forms.Padding(2);
            this.panel_info.Name = "panel_info";
            this.panel_info.Size = new System.Drawing.Size(345, 496);
            this.panel_info.TabIndex = 14;
            // 
            // pb_userimage
            // 
            this.pb_userimage.BackColor = System.Drawing.SystemColors.Control;
            this.pb_userimage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb_userimage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_userimage.Location = new System.Drawing.Point(124, 62);
            this.pb_userimage.Margin = new System.Windows.Forms.Padding(2);
            this.pb_userimage.Name = "pb_userimage";
            this.pb_userimage.Size = new System.Drawing.Size(113, 122);
            this.pb_userimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_userimage.TabIndex = 1;
            this.pb_userimage.TabStop = false;
            this.pb_userimage.Tag = "Default";
            this.pb_userimage.Click += new System.EventHandler(this.pb_usericon_Click);
            // 
            // PersonalInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(249)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(922, 570);
            this.Controls.Add(this.panel_info);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PersonalInfo";
            this.Text = "PersonalInfo";
            this.Load += new System.EventHandler(this.PersonalInfo_Load);
            this.panel_info.ResumeLayout(false);
            this.panel_info.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_userimage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_userimage;
        private System.Windows.Forms.Label lbl_note;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label lbl_userEmail;
        private System.Windows.Forms.TextBox txt_fullname;
        private System.Windows.Forms.Label lbl_userFullname;
        private System.Windows.Forms.DateTimePicker dtp_userbd;
        private System.Windows.Forms.Label lbl_userbd;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.Label lbl_userPhone;
        private System.Windows.Forms.Button btn_userInfo;
        private System.Windows.Forms.Timer progressTimer;
        private System.Windows.Forms.Label lbl_profile;
        private System.Windows.Forms.Panel panel_info;
    }
}