﻿namespace StudyHub
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.pnlMainContent = new System.Windows.Forms.Panel();
            this.pnlAccount = new System.Windows.Forms.Panel();
            this.btn_logout = new System.Windows.Forms.Button();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblBday = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.pbProfile = new System.Windows.Forms.PictureBox();
            this.shapeContainer4 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.pnlDashboard = new System.Windows.Forms.Panel();
            this.cbLevels = new System.Windows.Forms.ComboBox();
            this.lblDashboard = new System.Windows.Forms.Label();
            this.btn_darkmode = new System.Windows.Forms.Button();
            this.btnAddProject = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.flowLayoutPanelCards = new System.Windows.Forms.FlowLayoutPanel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.pbSearch = new System.Windows.Forms.PictureBox();
            this.flpProjects = new System.Windows.Forms.FlowLayoutPanel();
            this.lblEmptyMessage = new System.Windows.Forms.Label();
            this.pnlInbox = new System.Windows.Forms.Panel();
            this.lblMessage = new System.Windows.Forms.Label();
            this.flpMessages = new System.Windows.Forms.FlowLayoutPanel();
            this.shapeContainer3 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.pnlHistory = new System.Windows.Forms.Panel();
            this.dgv_transhistory = new System.Windows.Forms.DataGridView();
            this.ColUsername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDeadline = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblHistory = new System.Windows.Forms.Label();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.grpSideBar = new System.Windows.Forms.GroupBox();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.btnAccount = new System.Windows.Forms.Button();
            this.btnHistory = new System.Windows.Forms.Button();
            this.btnInbox = new System.Windows.Forms.Button();
            this.pnlMainContent.SuspendLayout();
            this.pnlAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfile)).BeginInit();
            this.pnlDashboard.SuspendLayout();
            this.flowLayoutPanelCards.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).BeginInit();
            this.flpProjects.SuspendLayout();
            this.pnlInbox.SuspendLayout();
            this.pnlHistory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_transhistory)).BeginInit();
            this.grpSideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMainContent
            // 
            this.pnlMainContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(249)))), ((int)(((byte)(238)))));
            this.pnlMainContent.Controls.Add(this.pnlDashboard);
            this.pnlMainContent.Controls.Add(this.pnlAccount);
            this.pnlMainContent.Controls.Add(this.pnlInbox);
            this.pnlMainContent.Controls.Add(this.pnlHistory);
            this.pnlMainContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMainContent.Location = new System.Drawing.Point(0, 0);
            this.pnlMainContent.Margin = new System.Windows.Forms.Padding(2);
            this.pnlMainContent.Name = "pnlMainContent";
            this.pnlMainContent.Size = new System.Drawing.Size(924, 571);
            this.pnlMainContent.TabIndex = 0;
            this.pnlMainContent.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_home_Paint);
            // 
            // pnlAccount
            // 
            this.pnlAccount.Controls.Add(this.btn_logout);
            this.pnlAccount.Controls.Add(this.lblPhone);
            this.pnlAccount.Controls.Add(this.lblEmail);
            this.pnlAccount.Controls.Add(this.lblBday);
            this.pnlAccount.Controls.Add(this.lblName);
            this.pnlAccount.Controls.Add(this.lblUser);
            this.pnlAccount.Controls.Add(this.pbProfile);
            this.pnlAccount.Controls.Add(this.shapeContainer4);
            this.pnlAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAccount.Location = new System.Drawing.Point(0, 0);
            this.pnlAccount.Name = "pnlAccount";
            this.pnlAccount.Size = new System.Drawing.Size(924, 571);
            this.pnlAccount.TabIndex = 10;
            this.pnlAccount.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlAccount_Paint_1);
            // 
            // btn_logout
            // 
            this.btn_logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_logout.Font = new System.Drawing.Font("Arial", 9F);
            this.btn_logout.Location = new System.Drawing.Point(798, 119);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(75, 34);
            this.btn_logout.TabIndex = 9;
            this.btn_logout.Text = "Logout";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.Location = new System.Drawing.Point(343, 230);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(104, 25);
            this.lblPhone.TabIndex = 5;
            this.lblPhone.Text = "Phone No.";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(343, 192);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(66, 25);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "Email:";
            // 
            // lblBday
            // 
            this.lblBday.AutoSize = true;
            this.lblBday.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBday.Location = new System.Drawing.Point(343, 154);
            this.lblBday.Name = "lblBday";
            this.lblBday.Size = new System.Drawing.Size(89, 25);
            this.lblBday.TabIndex = 3;
            this.lblBday.Text = "Birthday:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(343, 115);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(70, 25);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name:";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(193, 64);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(183, 37);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "User Profile";
            // 
            // pbProfile
            // 
            this.pbProfile.BackColor = System.Drawing.Color.Silver;
            this.pbProfile.Location = new System.Drawing.Point(199, 115);
            this.pbProfile.Name = "pbProfile";
            this.pbProfile.Size = new System.Drawing.Size(120, 145);
            this.pbProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbProfile.TabIndex = 0;
            this.pbProfile.TabStop = false;
            // 
            // shapeContainer4
            // 
            this.shapeContainer4.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer4.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer4.Name = "shapeContainer4";
            this.shapeContainer4.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape4});
            this.shapeContainer4.Size = new System.Drawing.Size(924, 571);
            this.shapeContainer4.TabIndex = 6;
            this.shapeContainer4.TabStop = false;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 200;
            this.lineShape4.X2 = 872;
            this.lineShape4.Y1 = 102;
            this.lineShape4.Y2 = 102;
            this.lineShape4.Click += new System.EventHandler(this.lineShape4_Click);
            // 
            // pnlDashboard
            // 
            this.pnlDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(249)))), ((int)(((byte)(238)))));
            this.pnlDashboard.Controls.Add(this.cbLevels);
            this.pnlDashboard.Controls.Add(this.lblDashboard);
            this.pnlDashboard.Controls.Add(this.btn_darkmode);
            this.pnlDashboard.Controls.Add(this.btnAddProject);
            this.pnlDashboard.Controls.Add(this.shapeContainer1);
            this.pnlDashboard.Controls.Add(this.flowLayoutPanelCards);
            this.pnlDashboard.Controls.Add(this.flpProjects);
            this.pnlDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDashboard.Location = new System.Drawing.Point(0, 0);
            this.pnlDashboard.Margin = new System.Windows.Forms.Padding(2);
            this.pnlDashboard.Name = "pnlDashboard";
            this.pnlDashboard.Size = new System.Drawing.Size(924, 571);
            this.pnlDashboard.TabIndex = 11;
            this.pnlDashboard.Paint += new System.Windows.Forms.PaintEventHandler(this.x);
            // 
            // cbLevels
            // 
            this.cbLevels.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbLevels.FormattingEnabled = true;
            this.cbLevels.Items.AddRange(new object[] {
            "All levels",
            "1st Year",
            "2nd Year",
            "3rd Year",
            "4th Year"});
            this.cbLevels.Location = new System.Drawing.Point(160, 158);
            this.cbLevels.Name = "cbLevels";
            this.cbLevels.Size = new System.Drawing.Size(121, 21);
            this.cbLevels.TabIndex = 6;
            this.cbLevels.Text = "All levels";
            this.cbLevels.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblDashboard
            // 
            this.lblDashboard.AutoSize = true;
            this.lblDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDashboard.Location = new System.Drawing.Point(152, 87);
            this.lblDashboard.Name = "lblDashboard";
            this.lblDashboard.Size = new System.Drawing.Size(224, 46);
            this.lblDashboard.TabIndex = 5;
            this.lblDashboard.Text = "Dashboard";
            // 
            // btn_darkmode
            // 
            this.btn_darkmode.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_darkmode.BackgroundImage")));
            this.btn_darkmode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_darkmode.FlatAppearance.BorderSize = 0;
            this.btn_darkmode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_darkmode.Location = new System.Drawing.Point(723, 21);
            this.btn_darkmode.Name = "btn_darkmode";
            this.btn_darkmode.Size = new System.Drawing.Size(29, 23);
            this.btn_darkmode.TabIndex = 3;
            this.btn_darkmode.UseVisualStyleBackColor = true;
            this.btn_darkmode.Click += new System.EventHandler(this.btn_darkmode_Click);
            // 
            // btnAddProject
            // 
            this.btnAddProject.BackgroundImage = global::StudyHub.Properties.Resources.add;
            this.btnAddProject.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddProject.FlatAppearance.BorderSize = 0;
            this.btnAddProject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProject.ForeColor = System.Drawing.Color.Transparent;
            this.btnAddProject.Location = new System.Drawing.Point(682, 21);
            this.btnAddProject.Name = "btnAddProject";
            this.btnAddProject.Size = new System.Drawing.Size(29, 23);
            this.btnAddProject.TabIndex = 2;
            this.btnAddProject.UseVisualStyleBackColor = true;
            this.btnAddProject.Click += new System.EventHandler(this.btnAddProject_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2});
            this.shapeContainer1.Size = new System.Drawing.Size(924, 571);
            this.shapeContainer1.TabIndex = 8;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape1";
            this.lineShape2.X1 = 160;
            this.lineShape2.X2 = 832;
            this.lineShape2.Y1 = 141;
            this.lineShape2.Y2 = 141;
            // 
            // flowLayoutPanelCards
            // 
            this.flowLayoutPanelCards.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanelCards.Controls.Add(this.txtSearch);
            this.flowLayoutPanelCards.Controls.Add(this.pbSearch);
            this.flowLayoutPanelCards.Location = new System.Drawing.Point(304, 18);
            this.flowLayoutPanelCards.Name = "flowLayoutPanelCards";
            this.flowLayoutPanelCards.Size = new System.Drawing.Size(368, 31);
            this.flowLayoutPanelCards.TabIndex = 7;
            // 
            // txtSearch
            // 
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(330, 20);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.Text = "Search";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // pbSearch
            // 
            this.pbSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbSearch.Image = global::StudyHub.Properties.Resources.search;
            this.pbSearch.Location = new System.Drawing.Point(339, 3);
            this.pbSearch.Name = "pbSearch";
            this.pbSearch.Size = new System.Drawing.Size(22, 20);
            this.pbSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSearch.TabIndex = 1;
            this.pbSearch.TabStop = false;
            this.pbSearch.Click += new System.EventHandler(this.pbSearch_Click);
            // 
            // flpProjects
            // 
            this.flpProjects.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpProjects.AutoScroll = true;
            this.flpProjects.Controls.Add(this.lblEmptyMessage);
            this.flpProjects.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpProjects.Location = new System.Drawing.Point(160, 197);
            this.flpProjects.Name = "flpProjects";
            this.flpProjects.Size = new System.Drawing.Size(505, 340);
            this.flpProjects.TabIndex = 9;
            this.flpProjects.WrapContents = false;
            // 
            // lblEmptyMessage
            // 
            this.lblEmptyMessage.AutoSize = true;
            this.lblEmptyMessage.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmptyMessage.Location = new System.Drawing.Point(3, 0);
            this.lblEmptyMessage.Name = "lblEmptyMessage";
            this.lblEmptyMessage.Size = new System.Drawing.Size(280, 19);
            this.lblEmptyMessage.TabIndex = 0;
            this.lblEmptyMessage.Text = "No projects found. Add your project now!";
            // 
            // pnlInbox
            // 
            this.pnlInbox.Controls.Add(this.lblMessage);
            this.pnlInbox.Controls.Add(this.flpMessages);
            this.pnlInbox.Controls.Add(this.shapeContainer3);
            this.pnlInbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlInbox.Location = new System.Drawing.Point(0, 0);
            this.pnlInbox.Name = "pnlInbox";
            this.pnlInbox.Size = new System.Drawing.Size(924, 571);
            this.pnlInbox.TabIndex = 10;
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(160, 61);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(169, 37);
            this.lblMessage.TabIndex = 1;
            this.lblMessage.Text = "Messages";
            // 
            // flpMessages
            // 
            this.flpMessages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpMessages.AutoScroll = true;
            this.flpMessages.Location = new System.Drawing.Point(162, 110);
            this.flpMessages.Name = "flpMessages";
            this.flpMessages.Size = new System.Drawing.Size(678, 409);
            this.flpMessages.TabIndex = 0;
            // 
            // shapeContainer3
            // 
            this.shapeContainer3.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer3.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            this.shapeContainer3.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3});
            this.shapeContainer3.Size = new System.Drawing.Size(924, 571);
            this.shapeContainer3.TabIndex = 2;
            this.shapeContainer3.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 166;
            this.lineShape3.X2 = 838;
            this.lineShape3.Y1 = 100;
            this.lineShape3.Y2 = 100;
            // 
            // pnlHistory
            // 
            this.pnlHistory.Controls.Add(this.dgv_transhistory);
            this.pnlHistory.Controls.Add(this.lblHistory);
            this.pnlHistory.Controls.Add(this.shapeContainer2);
            this.pnlHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlHistory.Location = new System.Drawing.Point(0, 0);
            this.pnlHistory.Name = "pnlHistory";
            this.pnlHistory.Size = new System.Drawing.Size(924, 571);
            this.pnlHistory.TabIndex = 10;
            // 
            // dgv_transhistory
            // 
            this.dgv_transhistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_transhistory.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgv_transhistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_transhistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColUsername,
            this.ColTitle,
            this.ColDeadline,
            this.ColStatus});
            this.dgv_transhistory.Location = new System.Drawing.Point(155, 158);
            this.dgv_transhistory.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_transhistory.Name = "dgv_transhistory";
            this.dgv_transhistory.RowHeadersVisible = false;
            this.dgv_transhistory.RowTemplate.Height = 24;
            this.dgv_transhistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_transhistory.Size = new System.Drawing.Size(704, 375);
            this.dgv_transhistory.TabIndex = 0;
            this.dgv_transhistory.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_transhistory_CellContentClick);
            // 
            // ColUsername
            // 
            this.ColUsername.HeaderText = "Username";
            this.ColUsername.Name = "ColUsername";
            // 
            // ColTitle
            // 
            this.ColTitle.HeaderText = "Project Title";
            this.ColTitle.Name = "ColTitle";
            // 
            // ColDeadline
            // 
            this.ColDeadline.HeaderText = "Deadline";
            this.ColDeadline.Name = "ColDeadline";
            // 
            // ColStatus
            // 
            this.ColStatus.HeaderText = "Status";
            this.ColStatus.Name = "ColStatus";
            // 
            // lblHistory
            // 
            this.lblHistory.AutoSize = true;
            this.lblHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHistory.Location = new System.Drawing.Point(149, 64);
            this.lblHistory.Name = "lblHistory";
            this.lblHistory.Size = new System.Drawing.Size(313, 37);
            this.lblHistory.TabIndex = 0;
            this.lblHistory.Text = "Transaction History";
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer2.Size = new System.Drawing.Size(924, 571);
            this.shapeContainer2.TabIndex = 3;
            this.shapeContainer2.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 157;
            this.lineShape1.X2 = 805;
            this.lineShape1.Y1 = 108;
            this.lineShape1.Y2 = 108;
            // 
            // grpSideBar
            // 
            this.grpSideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.grpSideBar.Controls.Add(this.btnDashboard);
            this.grpSideBar.Controls.Add(this.pbLogo);
            this.grpSideBar.Controls.Add(this.btnAccount);
            this.grpSideBar.Controls.Add(this.btnHistory);
            this.grpSideBar.Controls.Add(this.btnInbox);
            this.grpSideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.grpSideBar.Location = new System.Drawing.Point(0, 0);
            this.grpSideBar.Name = "grpSideBar";
            this.grpSideBar.Size = new System.Drawing.Size(100, 571);
            this.grpSideBar.TabIndex = 0;
            this.grpSideBar.TabStop = false;
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btnDashboard.BackgroundImage = global::StudyHub.Properties.Resources.dashboard;
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.ForeColor = System.Drawing.Color.Black;
            this.btnDashboard.Location = new System.Drawing.Point(1, 106);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(100, 89);
            this.btnDashboard.TabIndex = 2;
            this.btnDashboard.Text = "\r\n\r\n\r\n\r\n\r\nDashboard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // pbLogo
            // 
            this.pbLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbLogo.Image = global::StudyHub.Properties.Resources.studyhub_logo;
            this.pbLogo.Location = new System.Drawing.Point(0, 0);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(100, 102);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogo.TabIndex = 8;
            this.pbLogo.TabStop = false;
            // 
            // btnAccount
            // 
            this.btnAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.btnAccount.BackgroundImage = global::StudyHub.Properties.Resources.account;
            this.btnAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAccount.FlatAppearance.BorderSize = 0;
            this.btnAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccount.ForeColor = System.Drawing.Color.Black;
            this.btnAccount.Location = new System.Drawing.Point(0, 192);
            this.btnAccount.Name = "btnAccount";
            this.btnAccount.Size = new System.Drawing.Size(100, 89);
            this.btnAccount.TabIndex = 1;
            this.btnAccount.Text = "\r\n\r\n\r\n\r\n\r\nAccount\r\n";
            this.btnAccount.UseVisualStyleBackColor = false;
            this.btnAccount.Click += new System.EventHandler(this.btnAccount_Click);
            // 
            // btnHistory
            // 
            this.btnHistory.BackgroundImage = global::StudyHub.Properties.Resources.history;
            this.btnHistory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHistory.FlatAppearance.BorderSize = 0;
            this.btnHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHistory.Location = new System.Drawing.Point(0, 358);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(100, 89);
            this.btnHistory.TabIndex = 4;
            this.btnHistory.Text = "\r\n\r\n\r\n\r\n\r\nHistory";
            this.btnHistory.UseVisualStyleBackColor = true;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // btnInbox
            // 
            this.btnInbox.BackgroundImage = global::StudyHub.Properties.Resources.inbox;
            this.btnInbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInbox.FlatAppearance.BorderSize = 0;
            this.btnInbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInbox.Location = new System.Drawing.Point(0, 276);
            this.btnInbox.Name = "btnInbox";
            this.btnInbox.Size = new System.Drawing.Size(100, 86);
            this.btnInbox.TabIndex = 3;
            this.btnInbox.Text = "Inbox";
            this.btnInbox.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnInbox.UseVisualStyleBackColor = true;
            this.btnInbox.Click += new System.EventHandler(this.btnInbox_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 571);
            this.Controls.Add(this.grpSideBar);
            this.Controls.Add(this.pnlMainContent);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.pnlMainContent.ResumeLayout(false);
            this.pnlAccount.ResumeLayout(false);
            this.pnlAccount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfile)).EndInit();
            this.pnlDashboard.ResumeLayout(false);
            this.pnlDashboard.PerformLayout();
            this.flowLayoutPanelCards.ResumeLayout(false);
            this.flowLayoutPanelCards.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSearch)).EndInit();
            this.flpProjects.ResumeLayout(false);
            this.flpProjects.PerformLayout();
            this.pnlInbox.ResumeLayout(false);
            this.pnlInbox.PerformLayout();
            this.pnlHistory.ResumeLayout(false);
            this.pnlHistory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_transhistory)).EndInit();
            this.grpSideBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMainContent;
        private System.Windows.Forms.GroupBox grpSideBar;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Button btnInbox;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnAccount;
        private System.Windows.Forms.Button btnAddProject;
        private System.Windows.Forms.Button btn_darkmode;
        private System.Windows.Forms.Label lblDashboard;
        private System.Windows.Forms.ComboBox cbLevels;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelCards;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.PictureBox pbSearch;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.FlowLayoutPanel flpProjects;
        private System.Windows.Forms.Label lblEmptyMessage;
        private System.Windows.Forms.Panel pnlAccount;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblBday;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.PictureBox pbProfile;
        private System.Windows.Forms.Panel pnlDashboard;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.Panel pnlInbox;
        private System.Windows.Forms.FlowLayoutPanel flpMessages;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Panel pnlHistory;
        private System.Windows.Forms.Label lblHistory;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private System.Windows.Forms.DataGridView dgv_transhistory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColUsername;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDeadline;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColStatus;
        private System.Windows.Forms.Button btn_logout;

    }
}