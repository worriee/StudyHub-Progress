﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data; // Namespace required for virtual DataTable manipulation

namespace StudyHub
{
    public partial class Home : Form
    {
        // Sidebar active and inactive custom background colors
        Color activeColor = Color.FromArgb(250, 249, 238);   // Cream
        Color inactiveColor = Color.FromArgb(163, 177, 138); // Sage Green

        public Home()
        {
            InitializeComponent();
            ShowPage("Dashboard");
        }

        // Toggles active tab UI styles and manages multi-panel layout transitions
        private void ShowPage(string pageName)
        {
            pnlDashboard.Visible = false;
            pnlAccount.Visible = false;
            pnlInbox.Visible = false;
            pnlHistory.Visible = false;

            btnDashboard.BackColor = inactiveColor;
            btnAccount.BackColor = inactiveColor;
            btnInbox.BackColor = inactiveColor;
            btnHistory.BackColor = inactiveColor;

            btnDashboard.ForeColor = Color.Black;
            btnAccount.ForeColor = Color.Black;
            btnInbox.ForeColor = Color.Black;
            btnHistory.ForeColor = Color.Black;

            if (pageName == "Dashboard")
            {
                pnlDashboard.Visible = true;
                pnlDashboard.BringToFront();

                btnDashboard.BackColor = activeColor;
                btnDashboard.ForeColor = Color.Gray;

                btnAccount.BackColor = inactiveColor;
                btnAccount.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            else if (pageName == "Account")
            {
                pnlAccount.Visible = true;
                pnlAccount.BringToFront();

                btnAccount.BackColor = activeColor;
                btnAccount.ForeColor = Color.Gray;

                btnDashboard.BackColor = inactiveColor;
                btnDashboard.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            else if (pageName == "Inbox")
            {
                pnlInbox.Visible = true;
                pnlInbox.BringToFront();
                btnInbox.BackColor = activeColor;
                btnInbox.ForeColor = Color.Gray;
            }
            else if (pageName == "History")
            {
                pnlHistory.Visible = true;
                pnlHistory.BringToFront();
                btnHistory.BackColor = activeColor;
                btnHistory.ForeColor = Color.Gray;
            }
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ShowPage("Dashboard");
        }

        // Updates user profile labels dynamically using global UserSession cache properties
        private void btnAccount_Click(object sender, EventArgs e)
        {
            ShowPage("Account");

            pnlAccount.Visible = true;
            pnlDashboard.Visible = false;

            lblName.Text = "Name: " + UserSession.FullName;
            lblBday.Text = "Birthday: " + UserSession.Birthday;
            lblEmail.Text = "Email: " + UserSession.Email;
            lblPhone.Text = "Phone No. " + UserSession.Phone;

            if (UserSession.UserProfilePic != null)
            {
                pbProfile.Image = UserSession.UserProfilePic;
                pbProfile.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void btnInbox_Click(object sender, EventArgs e)
        {
            ShowPage("Inbox");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            ShowPage("History");
        }

        // Triggers search filter checking against names of cards inside flpProjects panel
        private void pbSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.ToLower();
            foreach (Control card in flpProjects.Controls)
            {
                card.Visible = card.Name.ToLower().Contains(query);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void x(object sender, PaintEventArgs e)
        {

        }

        // Loads both projects and transaction lists immediately on startup
        private void Home_Load(object sender, EventArgs e)
        {
            LoadProjectsFromDatabase();
            LoadTransactionHistory();
            cbLevels.SelectedIndex = 0; // ADDED: Sets default selection of the Year Level dropdown to "All levels" on startup
        }

        private void button1_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel_home_Paint(object sender, PaintEventArgs e) { }
        private void pnlAccount_Paint_1(object sender, PaintEventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }

        private void lineShape4_Click(object sender, EventArgs e)
        {

        }

        // Color structure theme mapping used for UI switching triggers
        bool isDarkMode = false;
        private void btn_darkmode_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;
            foreach (Control c in flpProjects.Controls)
            {
                DashboardCard card = c as DashboardCard;
                if (card != null)
                {
                    card.ApplyDarkMode(isDarkMode);
                }
            }

            if (isDarkMode)
            {
                this.BackColor = Color.FromArgb(102, 102, 102);
                pnlDashboard.BackColor = Color.FromArgb(102, 102, 102);
                lblDashboard.ForeColor = Color.White;
                lblEmptyMessage.ForeColor = Color.White;
                pnlAccount.BackColor = Color.FromArgb(102, 102, 102);
                pnlInbox.BackColor = Color.FromArgb(102, 102, 102);
                pnlHistory.BackColor = Color.FromArgb(102, 102, 102);
                lblHistory.BackColor = Color.Transparent;
                lblHistory.ForeColor = Color.White;
                txtSearch.BackColor = Color.FromArgb(102, 102, 102);
                txtSearch.ForeColor = Color.White;
                lblMessage.ForeColor = Color.White;
                lblPhone.ForeColor = Color.White;
                lblBday.ForeColor = Color.White;
                lblEmail.ForeColor = Color.White;
                lblName.ForeColor = Color.White;
                lblUser.ForeColor = Color.White;

                cbLevels.FlatStyle = FlatStyle.Flat;
                cbLevels.BackColor = Color.FromArgb(102, 102, 102);
                cbLevels.ForeColor = Color.White;

                dgv_transhistory.BackgroundColor = Color.FromArgb(45, 45, 45);
                dgv_transhistory.GridColor = Color.FromArgb(60, 60, 60);

                dgv_transhistory.DefaultCellStyle.BackColor = Color.FromArgb(55, 55, 55);
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.White;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(80, 80, 80);
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.White;

                dgv_transhistory.EnableHeadersVisualStyles = false;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                btn_darkmode.BackgroundImage = Properties.Resources.light;
            }
            else
            {
                this.BackColor = Color.FromArgb(250, 249, 230);
                pnlDashboard.BackColor = Color.White;
                lblDashboard.ForeColor = Color.Black;
                lblEmptyMessage.ForeColor = Color.Black;
                pnlAccount.BackColor = Color.White;
                pnlInbox.BackColor = Color.White;
                pnlHistory.BackColor = Color.White;
                lblHistory.BackColor = Color.Transparent;
                lblHistory.ForeColor = Color.Black;
                txtSearch.BackColor = Color.White;
                txtSearch.ForeColor = Color.Black;
                lblMessage.ForeColor = Color.Black;
                lblPhone.ForeColor = Color.Black;
                lblBday.ForeColor = Color.Black;
                lblEmail.ForeColor = Color.Black;
                lblName.ForeColor = Color.Black;
                lblUser.ForeColor = Color.Black;
                cbLevels.FlatStyle = FlatStyle.Flat;
                cbLevels.BackColor = Color.White;
                cbLevels.ForeColor = Color.Black;

                dgv_transhistory.BackgroundColor = Color.FromArgb(240, 240, 240);
                dgv_transhistory.GridColor = Color.LightGray;

                dgv_transhistory.DefaultCellStyle.BackColor = Color.White;
                dgv_transhistory.DefaultCellStyle.ForeColor = Color.Black;
                dgv_transhistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(163, 177, 138);
                dgv_transhistory.DefaultCellStyle.SelectionForeColor = Color.Black;

                dgv_transhistory.EnableHeadersVisualStyles = false;
                dgv_transhistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(163, 177, 138);
                dgv_transhistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;

                btn_darkmode.BackgroundImage = Properties.Resources.night_mode;
            }
        }

        // Activates new project dialog configuration and handles layout refreshes on return
        private void btnAddProject_Click(object sender, EventArgs e)
        {
            using (AddProject window = new AddProject(isDarkMode))
            {
                if (window.ShowDialog() == DialogResult.OK)
                {
                    // Clears the workspace and re-fetches updated project data directly from SQL
                    LoadProjectsFromDatabase();
                }
            }
        }

        private void dgv_transhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_userhistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Closes dashboard processes, clears cached authentication variables, and opens login prompt
        private void btn_logout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Logout Confirmation",
                                              MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Calls our helper class reset to completely flush cached credentials
                UserSession.Clear();

                Login window = new Login();
                window.Show();

                this.Hide();
            }
        }

        // Selects and populates all existing records inside UserControl table onto FlowLayoutPanel
        private void LoadProjectsFromDatabase()
        {
            flpProjects.Controls.Clear();
            string query = "SELECT FullName, Deadline, ProjectTitle, Notes, FileAttached, YearLevel FROM UserControl ORDER BY ProjectId DESC";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            bool hasProjects = false;
                            while (reader.Read())
                            {
                                hasProjects = true;
                                DashboardCard card = new DashboardCard(isDarkMode);

                                string uploaderName = reader["FullName"].ToString();
                                string deadline = reader["Deadline"].ToString();
                                string title = reader["ProjectTitle"].ToString();
                                string notes = reader["Notes"] != DBNull.Value ? reader["Notes"].ToString() : "";
                                string file = reader["FileAttached"] != DBNull.Value ? reader["FileAttached"].ToString() : "";
                                string yearLevel = reader["YearLevel"] != DBNull.Value ? reader["YearLevel"].ToString() : "N/A"; // Reads column value

                                // Passes the year level down to the visual card properties
                                card.SetProjectDetails(uploaderName, deadline, title, notes, file, yearLevel);
                                flpProjects.Controls.Add(card);
                            }

                            lblEmptyMessage.Visible = !hasProjects;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading projects: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Queries the transHistory table with a filter to strictly fetch only the active user's transactions
        public void LoadTransactionHistory()
        {
            string query = "SELECT Username, ProjectTitle, Deadline, Status FROM transHistory WHERE Username = @Username ORDER BY Id DESC";

            try
            {
                using (SqlConnection conn = Database.GetTransConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Binds the session's active username string securely to the query parameter
                        cmd.Parameters.AddWithValue("@Username", UserSession.Username);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt); // Stream filtered database records directly to datatable object

                            // Bind structural dataset straight to visual DataGridView UI element
                            dgv_transhistory.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading transactions: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ADDED: Triggers when selecting a level from the cbLevels ComboBox to filter DashboardCards
        private void cbLevels_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedLevel = cbLevels.SelectedItem != null ? cbLevels.SelectedItem.ToString() : "All levels";

            foreach (Control c in flpProjects.Controls)
            {
                DashboardCard card = c as DashboardCard;
                if (card != null)
                {
                    // Show everything if "All levels" is chosen, otherwise check if card matches selected year level
                    if (selectedLevel.Equals("All levels", StringComparison.OrdinalIgnoreCase))
                    {
                        card.Visible = true;
                    }
                    else
                    {
                        card.Visible = card.YearLevel.Equals(selectedLevel, StringComparison.OrdinalIgnoreCase);
                    }
                }
            }
        }
    }
}