﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class DashboardCard : UserControl
    {
        public DashboardCard()
        {
            InitializeComponent();
        }

        public DashboardCard(bool isDarkMode)
        {
            InitializeComponent();
            ApplyDarkMode(isDarkMode);
        }

        public void SetProjectDetails(string name, string deadline, string title, string note, string filename)
        {
            lblUser.Text = "Name: " + name;
            lbldeadline.Text = "Deadline: " + deadline;
            lblProjectTitle.Text = "Title: " + title;
            lblNote.Text = "Note: " + note;
            lbl_file.Text = "Attached: " + filename;
        }

        public void ApplyDarkMode(bool isDarkMode)
        {
            if (isDarkMode)
            {
                this.BackColor = Color.FromArgb(84, 84, 84); // Dark background for the card
                lblNote.ForeColor = Color.White;
                lblProjectTitle.ForeColor = Color.White;
                lbldeadline.ForeColor = Color.White;
                lblUser.ForeColor = Color.White;
                lbl_file.ForeColor = Color.White;
                lineShape1.BorderColor = Color.White;
                btnAccept.BackColor = Color.FromArgb(66, 66, 66);
                btnAccept.ForeColor = Color.White;
            }
            else
            {
                // Light Mode Reset
                this.BackColor = Color.FromArgb(218, 210, 188);
                lblNote.ForeColor = Color.Black;
                lblProjectTitle.ForeColor = Color.Black;
                lbldeadline.ForeColor = Color.Black;
                lblUser.ForeColor = Color.Black;
                lbl_file.ForeColor = Color.Black;
                lineShape1.BorderColor = Color.Black;
                btnAccept.BackColor = Color.FromArgb(163, 177, 138);
                btnAccept.ForeColor = Color.Black;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbldeadline_Click(object sender, EventArgs e)
        {

        }

        private void DashboardCard_Load(object sender, EventArgs e)
        {

        }

        private void btnAccept_Click(object sender, EventArgs e)
        {

        }

        private void lblProjectTitle_Click(object sender, EventArgs e)
        {

        }
    }
}
