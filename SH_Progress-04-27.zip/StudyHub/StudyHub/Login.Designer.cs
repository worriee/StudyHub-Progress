﻿namespace StudyHub
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.username = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_usn = new System.Windows.Forms.TextBox();
            this.textBox_pass = new System.Windows.Forms.TextBox();
            this.btn_action = new System.Windows.Forms.Button();
            this.lbl_action = new System.Windows.Forms.LinkLabel();
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.panel_login = new System.Windows.Forms.Panel();
            this.pb_usericon = new System.Windows.Forms.PictureBox();
            this.panel_login.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_usericon)).BeginInit();
            this.SuspendLayout();
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.Location = new System.Drawing.Point(50, 250);
            this.username.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(74, 20);
            this.username.TabIndex = 1;
            this.username.Text = "Username:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 323);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Password:";
            // 
            // textBox_usn
            // 
            this.textBox_usn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_usn.Location = new System.Drawing.Point(52, 272);
            this.textBox_usn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_usn.Name = "textBox_usn";
            this.textBox_usn.Size = new System.Drawing.Size(231, 26);
            this.textBox_usn.TabIndex = 3;
            // 
            // textBox_pass
            // 
            this.textBox_pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_pass.Location = new System.Drawing.Point(52, 345);
            this.textBox_pass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_pass.Name = "textBox_pass";
            this.textBox_pass.Size = new System.Drawing.Size(231, 26);
            this.textBox_pass.TabIndex = 4;
            this.textBox_pass.UseSystemPasswordChar = true;
            // 
            // btn_action
            // 
            this.btn_action.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(210)))), ((int)(((byte)(188)))));
            this.btn_action.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_action.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_action.Location = new System.Drawing.Point(113, 392);
            this.btn_action.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_action.Name = "btn_action";
            this.btn_action.Size = new System.Drawing.Size(112, 34);
            this.btn_action.TabIndex = 5;
            this.btn_action.Text = "Signup";
            this.btn_action.UseVisualStyleBackColor = false;
            this.btn_action.Click += new System.EventHandler(this.btn_action_Click);
            // 
            // lbl_action
            // 
            this.lbl_action.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lbl_action.AutoSize = true;
            this.lbl_action.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_action.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.lbl_action.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.lbl_action.Location = new System.Drawing.Point(86, 440);
            this.lbl_action.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_action.Name = "lbl_action";
            this.lbl_action.Size = new System.Drawing.Size(180, 16);
            this.lbl_action.TabIndex = 6;
            this.lbl_action.TabStop = true;
            this.lbl_action.Text = "Login with existing account.";
            this.lbl_action.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.AutoSize = true;
            this.lbl_welcome.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.Location = new System.Drawing.Point(73, 175);
            this.lbl_welcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(217, 32);
            this.lbl_welcome.TabIndex = 7;
            this.lbl_welcome.Text = "Welcome Back!";
            this.lbl_welcome.Visible = false;
            this.lbl_welcome.Click += new System.EventHandler(this.lbl_welcome_Click);
            // 
            // panel_login
            // 
            this.panel_login.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.panel_login.Controls.Add(this.pb_usericon);
            this.panel_login.Controls.Add(this.lbl_action);
            this.panel_login.Controls.Add(this.lbl_welcome);
            this.panel_login.Controls.Add(this.btn_action);
            this.panel_login.Controls.Add(this.textBox_usn);
            this.panel_login.Controls.Add(this.label1);
            this.panel_login.Controls.Add(this.textBox_pass);
            this.panel_login.Controls.Add(this.username);
            this.panel_login.Location = new System.Drawing.Point(270, 32);
            this.panel_login.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(345, 496);
            this.panel_login.TabIndex = 8;
            this.panel_login.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_login_Paint);
            // 
            // pb_usericon
            // 
            this.pb_usericon.BackColor = System.Drawing.Color.Transparent;
            this.pb_usericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb_usericon.Image = global::StudyHub.Properties.Resources.userr;
            this.pb_usericon.Location = new System.Drawing.Point(113, 35);
            this.pb_usericon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pb_usericon.Name = "pb_usericon";
            this.pb_usericon.Size = new System.Drawing.Size(112, 122);
            this.pb_usericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_usericon.TabIndex = 0;
            this.pb_usericon.TabStop = false;
            this.pb_usericon.Click += new System.EventHandler(this.pb_usericon_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(249)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(924, 571);
            this.Controls.Add(this.panel_login);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_usericon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_usericon;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_usn;
        private System.Windows.Forms.TextBox textBox_pass;
        private System.Windows.Forms.Button btn_action;
        private System.Windows.Forms.LinkLabel lbl_action;
        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.Panel panel_login;
    }
}

