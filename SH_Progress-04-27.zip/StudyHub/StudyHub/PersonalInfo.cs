﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace StudyHub
{
    public partial class PersonalInfo : Form
    {
        public PersonalInfo()
        {
            InitializeComponent();
        }

        private void pb_usericon_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pb_userimage.Image = Image.FromFile(ofd.FileName);
                pb_userimage.Tag = "Uploaded";
            }
        }

        private void btn_userInfo_Click(object sender, EventArgs e)
        {
            // --- 1. Profile Picture Validation ---
            // We check if the Tag is still null (meaning no file was selected)
            if (pb_userimage.Image == null || pb_userimage.Tag == null || pb_userimage.Tag.ToString() != "Uploaded")
            {
                MessageBox.Show("Please upload a profile photo first.", "Missing Photo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // --- 2. Full Name Validation ---
            if (string.IsNullOrWhiteSpace(txt_fullname.Text))
            {
                MessageBox.Show("Please enter your Full Name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_fullname.Focus();
                return;
            }

            // --- 3. Phone Number Validation (Philippine Standard: 11 digits, starts with 09) ---
            if (!Regex.IsMatch(txt_phone.Text, @"^09[0-9]{9}$"))
            {
                MessageBox.Show("Please enter a valid 11-digit phone number starting with 09.", "Invalid Phone", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_phone.Focus();
                return;
            }

            // --- 4. Email Validation ---
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(txt_email.Text, emailPattern))
            {
                MessageBox.Show("Please enter a valid email address (e.g., user@gmail.com).", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_email.Focus();
                return;
            }

            // --- 5. Birthday & Age Validation ---
            DateTime bday = dtp_userbd.Value;
            DateTime today = DateTime.Today;
            int age = today.Year - bday.Year;
            if (bday > today.AddYears(-age)) age--; // Precision age adjustment

            if (bday >= today)
            {
                MessageBox.Show("Birthday cannot be today or in the future.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (age < 15) // Basic age gate for students
            {
                MessageBox.Show("You must be at least 15 years old to use StudyHub.", "Age Restriction", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // --- ALL VALIDATIONS PASSED ---
            // Save the name to your session so the Dashboard shows it
            UserSession.FullName = txt_fullname.Text;
            UserSession.Email = txt_email.Text;
            UserSession.Phone = txt_phone.Text;
            UserSession.Birthday = dtp_userbd.Value.ToShortDateString();
            UserSession.UserProfilePic = pb_userimage.Image;

            Home window = new Home();
            window.Show();
            this.Hide();
        }

        int progressWidth = 0;
        private void progressTimer_Tick(object sender, EventArgs e)
        {
            int targetWidth = CalculateTargetProgress();

            if (progressWidth < targetWidth)
            {
                progressWidth += 2; // Speed of the line growing
            }
            else if (progressWidth > targetWidth)
            {
                progressWidth -= 2; // Line shrinks if user deletes text
            }

            btn_userInfo.Invalidate();
        }

        private int CalculateTargetProgress()
        {
            int completedFields = 0;

            if (pb_userimage.Tag != null && pb_userimage.Tag.ToString() == "Uploaded") completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_fullname.Text)) completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_email.Text)) completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_phone.Text)) completedFields++;
            if (dtp_userbd.Value.Date != DateTime.Today) completedFields++;

            // 20 per fields to reach 100% when multiplied to 5
            return completedFields * 20;
        }

        private void btn_userInfo_Paint(object sender, PaintEventArgs e)
        {
            Pen p = new Pen(Color.Black, 1);
            int w = btn_userInfo.Width;
            int h = btn_userInfo.Height;

            // Total distance the line travels (Perimeter)
            float totalPerimeter = (w * 2) + (h * 2);
            float currentDist = (totalPerimeter * progressWidth) / 100f;

            // Draw Bottom (Left to Right)
            float drawBottom = Math.Min(currentDist, w);
            if (drawBottom > 0)
                e.Graphics.DrawLine(p, 0, h - 2, drawBottom, h - 2);

            // Draw Right (Bottom to Top)
            if (currentDist > w)
            {
                float drawRight = Math.Min(currentDist - w, h);
                e.Graphics.DrawLine(p, w - 2, h, w - 2, h - drawRight);
            }

            // Draw Top (Right to Left)
            if (currentDist > (w + h))
            {
                float drawTop = Math.Min(currentDist - (w + h), w);
                e.Graphics.DrawLine(p, w, 2, w - drawTop, 2);
            }

            // Draw Left (Top to Bottom)
            if (currentDist > (w * 2 + h))
            {
                float drawLeft = Math.Min(currentDist - (w * 2 + h), h);
                e.Graphics.DrawLine(p, 2, 0, 2, drawLeft);
            }
        }

        private void lbl_profile_Click(object sender, EventArgs e)
        {

        }

        private void PersonalInfo_Load(object sender, EventArgs e)
        {

        }
    }
}
