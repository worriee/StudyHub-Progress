﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace StudyHub
{
    public static class UserSession
    {
        public static string FullName;
        public static string Birthday;
        public static string Email;
        public static string Phone;
        public static Image UserProfilePic;
    }
}
