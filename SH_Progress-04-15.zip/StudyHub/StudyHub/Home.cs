﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class Home : Form
    {
        // Your custom colors
        // Para rana sa sidebar
        Color activeColor = Color.FromArgb(250, 249, 238);   // Cream
        Color inactiveColor = Color.FromArgb(163, 177, 138); // Sage Green

        public Home()
        {
            InitializeComponent();
            ShowPage("Dashboard");
        }



        private void ShowPage(string pageName)
        {
            // 1. Hide all panels
            pnlDashboard.Visible = false;
            pnlAccount.Visible = false;
            pnlInbox.Visible = false;
            pnlHistory.Visible = false;

            // 2. Reset sidebar buttons to sage green
            btnDashboard.BackColor = inactiveColor;
            btnAccount.BackColor = inactiveColor;
            btnInbox.BackColor = inactiveColor;
            btnHistory.BackColor = inactiveColor;

            // Reset text colors
            btnDashboard.ForeColor = Color.Black;
            btnAccount.ForeColor = Color.Black;
            btnInbox.ForeColor = Color.Black;
            btnHistory.ForeColor = Color.Black;

            // 3. Dashboard Logic
            if (pageName == "Dashboard")
            {
                pnlDashboard.Visible = true;
                pnlDashboard.BringToFront(); //

                btnDashboard.BackColor = activeColor;
                btnDashboard.ForeColor = Color.Gray;

                btnAccount.BackColor = inactiveColor;
                btnAccount.ForeColor = Color.Black;


                // Keep the others inactive
                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            // 3. Account Logic
            else if (pageName == "Account")
            {
                pnlAccount.Visible = true;
                pnlAccount.BringToFront();

                btnAccount.BackColor = activeColor;
                btnAccount.ForeColor = Color.Gray;

                btnDashboard.BackColor = inactiveColor;
                btnDashboard.ForeColor = Color.Black;

                btnHistory.BackColor = inactiveColor;
                btnInbox.BackColor = inactiveColor;
            }
            // 4. Inbox Logic
            else if (pageName == "Inbox")
            {
                pnlInbox.Visible = true;
                pnlInbox.BringToFront();
                btnInbox.BackColor = activeColor;
                btnInbox.ForeColor = Color.Gray;
            }
             // 5. History Logic
            else if (pageName == "History")
            {
                pnlHistory.Visible = true;
                pnlHistory.BringToFront();
                btnHistory.BackColor = activeColor;
                btnHistory.ForeColor = Color.Gray;
            }
        }

        // --- SIDEBAR CLICKS ---
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ShowPage("Dashboard");
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            ShowPage("Account");
        }

        private void btnInbox_Click(object sender, EventArgs e)
        {
            ShowPage("Inbox");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            ShowPage("History");
        }

        // --- SEARCH LOGIC (Keeps the Designer happy!) ---
        private void pbSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.ToLower();
            // This filters the cards in your flpProjects
            foreach (Control card in flpProjects.Controls)
            {
                card.Visible = card.Name.ToLower().Contains(query);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            // Placeholder for search box logic
        }

        private void x(object sender, PaintEventArgs e)
        {
            // wala rapud ni ahak. LIKAY OG DOUBLE PRESS dol aron dili ma in ani kay diko kabaw unsaon pagremove
        }

        // --- EMERGENCY PLACEHOLDERS (DO NOT DELETE) ---
        private void Home_Load(object sender, EventArgs e) { }
        private void button1_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel_home_Paint(object sender, PaintEventArgs e) { }
        private void pnlAccount_Paint_1(object sender, PaintEventArgs e) { }
        private void btnAccount_Click_1(object sender, EventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }

        private void lineShape4_Click(object sender, EventArgs e)
        {
            //wala rani ahak
        }

        bool isDarkMode = false; //toggle darkmode btn
        private void btn_darkmode_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;

            if (isDarkMode)
            {
                // dark mode color
                this.BackColor = Color.FromArgb(30, 30, 30);
                pnlDashboard.BackColor = Color.FromArgb(45, 45, 45); 
                lblDashboard.ForeColor = Color.White;
                pnlAccount.BackColor = Color.FromArgb(45, 45, 45);
                pnlInbox.BackColor = Color.FromArgb(45, 45, 45);
                pnlHistory.BackColor = Color.FromArgb(45, 45, 45);
                lblHistory.ForeColor = Color.White;
                txtSearch.BackColor = Color.FromArgb(60, 60, 60);
                txtSearch.ForeColor = Color.White;

                // change btn icon to day
                btn_darkmode.BackgroundImage = Properties.Resources.day_mode;
            }
            else
            {
                // default colors
                this.BackColor = Color.FromArgb(250, 249, 230);
                pnlDashboard.BackColor = Color.White;
                lblDashboard.ForeColor = Color.Black;
                pnlAccount.BackColor = Color.White;
                pnlInbox.BackColor = Color.White;
                pnlHistory.BackColor = Color.White;
                lblHistory.BackColor = Color.White;
                txtSearch.BackColor = Color.White;
                txtSearch.ForeColor = Color.Black;
         
                btn_darkmode.BackgroundImage = Properties.Resources.night_mode;
            }
        }

        private void btnAddProject_Click(object sender, EventArgs e)
        {

        }
     
    }
}