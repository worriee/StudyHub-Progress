﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void pb_usericon_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (btn_action.Text == "Signup")
            {
                btn_action.Text = "Login";
                lbl_welcome.Text = "Welcome Back!";
                lbl_welcome.Visible = true;
                lbl_action.Text = "Signup/Create New Account";
            }
            else
            {
                btn_action.Text = "Signup";
                lbl_welcome.Visible = false;
                lbl_action.Text = "Login with existing account.";
            }
        }

        private void btn_action_Click(object sender, EventArgs e)
        {
            PersonalInfo window = new PersonalInfo();
            window.Show();
            this.Hide();
        }

        private void lbl_welcome_Click(object sender, EventArgs e)
        {

        }

        private void panel_login_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
