﻿namespace StudyHub
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb_usericon = new System.Windows.Forms.PictureBox();
            this.username = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_usn = new System.Windows.Forms.TextBox();
            this.textBox_pass = new System.Windows.Forms.TextBox();
            this.btn_action = new System.Windows.Forms.Button();
            this.lbl_action = new System.Windows.Forms.LinkLabel();
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.panel_login = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pb_usericon)).BeginInit();
            this.panel_login.SuspendLayout();
            this.SuspendLayout();
            // 
            // pb_usericon
            // 
            this.pb_usericon.BackColor = System.Drawing.SystemColors.Control;
            this.pb_usericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb_usericon.Image = global::StudyHub.Properties.Resources.userr;
            this.pb_usericon.Location = new System.Drawing.Point(157, 42);
            this.pb_usericon.Name = "pb_usericon";
            this.pb_usericon.Size = new System.Drawing.Size(150, 150);
            this.pb_usericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_usericon.TabIndex = 0;
            this.pb_usericon.TabStop = false;
            this.pb_usericon.Click += new System.EventHandler(this.pb_usericon_Click);
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.Location = new System.Drawing.Point(66, 308);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(91, 24);
            this.username.TabIndex = 1;
            this.username.Text = "Username:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(66, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Password:";
            // 
            // textBox_usn
            // 
            this.textBox_usn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_usn.Location = new System.Drawing.Point(70, 335);
            this.textBox_usn.Name = "textBox_usn";
            this.textBox_usn.Size = new System.Drawing.Size(307, 30);
            this.textBox_usn.TabIndex = 3;
            // 
            // textBox_pass
            // 
            this.textBox_pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_pass.Location = new System.Drawing.Point(70, 425);
            this.textBox_pass.Name = "textBox_pass";
            this.textBox_pass.Size = new System.Drawing.Size(307, 30);
            this.textBox_pass.TabIndex = 4;
            // 
            // btn_action
            // 
            this.btn_action.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_action.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_action.Location = new System.Drawing.Point(157, 477);
            this.btn_action.Name = "btn_action";
            this.btn_action.Size = new System.Drawing.Size(150, 42);
            this.btn_action.TabIndex = 5;
            this.btn_action.Text = "Signup";
            this.btn_action.UseVisualStyleBackColor = true;
            this.btn_action.Click += new System.EventHandler(this.btn_action_Click);
            // 
            // lbl_action
            // 
            this.lbl_action.ActiveLinkColor = System.Drawing.Color.Blue;
            this.lbl_action.AutoSize = true;
            this.lbl_action.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_action.LinkColor = System.Drawing.Color.Black;
            this.lbl_action.Location = new System.Drawing.Point(125, 533);
            this.lbl_action.Name = "lbl_action";
            this.lbl_action.Size = new System.Drawing.Size(209, 19);
            this.lbl_action.TabIndex = 6;
            this.lbl_action.TabStop = true;
            this.lbl_action.Text = "Login with existing account.";
            this.lbl_action.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.AutoSize = true;
            this.lbl_welcome.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.Location = new System.Drawing.Point(97, 215);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(266, 40);
            this.lbl_welcome.TabIndex = 7;
            this.lbl_welcome.Text = "Welcome Back!";
            this.lbl_welcome.Visible = false;
            this.lbl_welcome.Click += new System.EventHandler(this.lbl_welcome_Click);
            // 
            // panel_login
            // 
            this.panel_login.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_login.Controls.Add(this.pb_usericon);
            this.panel_login.Controls.Add(this.lbl_action);
            this.panel_login.Controls.Add(this.lbl_welcome);
            this.panel_login.Controls.Add(this.btn_action);
            this.panel_login.Controls.Add(this.textBox_usn);
            this.panel_login.Controls.Add(this.label1);
            this.panel_login.Controls.Add(this.textBox_pass);
            this.panel_login.Controls.Add(this.username);
            this.panel_login.Location = new System.Drawing.Point(110, 45);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(460, 610);
            this.panel_login.TabIndex = 8;
            this.panel_login.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_login_Paint);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 701);
            this.Controls.Add(this.panel_login);
            this.Name = "Login";
            this.Text = "Login";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pb_usericon)).EndInit();
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_usericon;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_usn;
        private System.Windows.Forms.TextBox textBox_pass;
        private System.Windows.Forms.Button btn_action;
        private System.Windows.Forms.LinkLabel lbl_action;
        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.Panel panel_login;
    }
}

