﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyHub
{
    public partial class PersonalInfo : Form
    {
        public PersonalInfo()
        {
            InitializeComponent();
        }

        private void pb_usericon_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pb_userimage.Image = Image.FromFile(ofd.FileName);
                pb_userimage.Tag = "Uploaded";
            }
        }

        private void btn_userInfo_Click(object sender, EventArgs e)
        {
            Home window = new Home();
            window.Show();
            this.Hide();
        }

        int progressWidth = 0;
        private void progressTimer_Tick(object sender, EventArgs e)
        {
            int targetWidth = CalculateTargetProgress();

            if (progressWidth < targetWidth)
            {
                progressWidth += 2; // Speed of the line growing
            }
            else if (progressWidth > targetWidth)
            {
                progressWidth -= 2; // Line shrinks if user deletes text
            }

            btn_userInfo.Invalidate();
        }

        private int CalculateTargetProgress()
        {
            int completedFields = 0;

            if (pb_userimage.Tag != null && pb_userimage.Tag.ToString() == "Uploaded") completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_fullname.Text)) completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_email.Text)) completedFields++;
            if (!string.IsNullOrWhiteSpace(txt_phone.Text)) completedFields++;
            if (dtp_userbd.Value.Date != DateTime.Today) completedFields++;

            // 20 per fields to reach 100% when multiplied to 5
            return completedFields * 20;
        }

        private void btn_userInfo_Paint(object sender, PaintEventArgs e)
        {
            Pen p = new Pen(Color.Black, 1);
            int w = btn_userInfo.Width;
            int h = btn_userInfo.Height;

            // Total distance the line travels (Perimeter)
            float totalPerimeter = (w * 2) + (h * 2);
            float currentDist = (totalPerimeter * progressWidth) / 100f;

            // Draw Bottom (Left to Right)
            float drawBottom = Math.Min(currentDist, w);
            if (drawBottom > 0)
                e.Graphics.DrawLine(p, 0, h - 2, drawBottom, h - 2);

            // Draw Right (Bottom to Top)
            if (currentDist > w)
            {
                float drawRight = Math.Min(currentDist - w, h);
                e.Graphics.DrawLine(p, w - 2, h, w - 2, h - drawRight);
            }

            // Draw Top (Right to Left)
            if (currentDist > (w + h))
            {
                float drawTop = Math.Min(currentDist - (w + h), w);
                e.Graphics.DrawLine(p, w, 2, w - drawTop, 2);
            }

            // Draw Left (Top to Bottom)
            if (currentDist > (w * 2 + h))
            {
                float drawLeft = Math.Min(currentDist - (w * 2 + h), h);
                e.Graphics.DrawLine(p, 2, 0, 2, drawLeft);
            }
        }

        private void lbl_profile_Click(object sender, EventArgs e)
        {

        }
    }
}
